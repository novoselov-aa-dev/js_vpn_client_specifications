/******/ (() => { // webpackBootstrap
var __webpack_exports__ = {};
const _browser = typeof browser !== 'undefined' ? browser : chrome;

_browser.runtime.onMessage.addListener((message, sender) => {
  var _document$querySelect, _document$querySelect2;

  if (sender.id !== _browser.runtime.id || sender.origin !== 'null') return;
  if (!(message === null || message === void 0 ? void 0 : message['show update payment info'])) return;
  (_document$querySelect = document.querySelector('.paddle_button.nolink')) === null || _document$querySelect === void 0 ? void 0 : (_document$querySelect2 = _document$querySelect.click) === null || _document$querySelect2 === void 0 ? void 0 : _document$querySelect2.call(_document$querySelect);
});
/******/ })()
;