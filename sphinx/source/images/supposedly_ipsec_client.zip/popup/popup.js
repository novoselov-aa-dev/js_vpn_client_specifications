(()=>{"use strict";var e,t={9206:(e,t,i)=>{var o=i(5215),n=i(8897);const s={add:e=>(0,n.Z)({type:"actions.favorites.add",country:e}),remove:e=>(0,n.Z)({type:"actions.favorites.remove",country:e})},r=async({email:e,password:t})=>{let i=await(0,n.Z)({type:"actions.login",data:{email:e,password:t}});if(i.success)return i.success;if(i.error){let{status:e,responseText:t,message:o}=i.error,n=new Error(o);throw void 0!==e&&(n.status=e),void 0!==t&&(n.responseText=t),n}},a=()=>(0,n.Z)({type:"actions.logout"});var l=i(6492),c=i.n(l);const d="\np, ul, ol, td, th{\n  padding: 0;\n  margin: 0;\n}\n\ntable {\n  border-collapse: collapse;\n}\n\nul, ol{\n  list-style: none;\n}\n";var p=i(3357),u=i(2338);class h extends o.oi{render(){return o.dy`
    <style>
    ${d}
    :host{
      display: flex;
      position: absolute;
      top: 56px;
      width: 100%;
      bottom: 0px;
      left: 0px;
      background: #fff;
      align-items: center;
    }
    :host > .In{
      padding: 0 15px;
    }

    .Title{
      color: #9a453b;
      text-align: center;
      font-size: 18px;
      font-weight: 600;
      color: #994136;
      padding-bottom: 12px;
    }
    .Title::before{
      content: '';
      display: block;
      background: url( '/images/account_locked.svg' ) 50% 50% no-repeat;
      width: 40px;
      padding-top: 53px;
      height: 0;
      overflow: hidden;
      margin: 0 auto;
      margin-bottom: 15px;
    }

    .Text{
      color: #919191;
      font-size: 14px;
      line-height: 1.4;
      text-align: center;
    }
    .Text > p{
      padding-bottom: 1em;
    }
    .Text > p:last-child{
      padding-bottom: 0;
    }

    .ButtonOut{
      text-align: center;
      padding-top: 35px;
    }
    .Button{
      display: inline-block;
      vertical-align: top;
      background: #3d973f;
      cursor: pointer;
      color: #fff;
      border-radius: 4px;
      background: #3d973f;
      height: 45px;
      line-height: 42px;
      font-size: 17px;
      text-align: center;
      padding: 0 40px;
      text-decoration: none;
    }
    .Button:hover{
      text-decoration: none;
    }

    .Link{
      padding-top: 20px;
      text-align: center;
    }
    .Link span{
      text-decoration: underline;
      cursor: pointer;
      color: #959595;
    }
    .Link span:hover{
      text-decoration: none;
    }

    .CloseTrigger{
      position: absolute;
      top: calc( -56px + 17px );
      right: 5px;
      width: 25px;
      height: 25px;
      overflow:hidden;
      cursor: pointer;
    }
    </style>

    <div class="In">
      <div class="Title">
        Your Account Has Been Suspended
      </div>
      <div class="Text">
        <p>Unfortunately, we were unable to charge the card on record.</p>
        <p>We saved your account and you can pick up where you left off by restoring your account below.</p>
      </div>
      <div class="ButtonOut"><!--
     --><a class="Button" href="${this.restoreUrl}" target="_blank" @click="${this.restore}">Restore my account</a><!--
   --></div>
      <div class="Link"><!--
      --><span @click="${this.hide}">I am seeing this message in error</span><!--
   --></div>
      <div class="CloseTrigger" @click="${this.logout}"></div>
    </div>`}constructor(){super(),this.restoreUrl=(()=>{const e=new URL(c().baseUrl+"/en/accounts/index");return e.searchParams.set("utm_source","chromium extension"),e.searchParams.set("utm_medium","account_lockout_screen"),e.toString()})()}async hide(){p.Z.full({category:"Exp164",action:"Lockout",label:"Error"});const e=this.animate([{opacity:"1"},{opacity:"0"}],{duration:300,easing:"linear"});await new Promise((t=>{e.onfinish=t})),this.remove()}async logout(){p.Z.full({category:"Exp164",action:"Lockout",label:"Logout"}),a();const e=this.animate([{opacity:"1"},{opacity:"0"}],{duration:300,easing:"linear"});await new Promise((t=>{e.onfinish=t})),this.remove()}restore(){p.Z.full({category:"Exp164",action:"Lockout",label:"Restore"}),u.Z.set("account suspended restore","initiated"),window&&window.close&&window.close()}}customElements.define("account-suspended",h);const g=({duration:e,action:t})=>{let i=performance.now();return new Promise((o=>{let n=s=>{if(s-i>=e)return void o();t((s-i)/e),requestAnimationFrame(n)};requestAnimationFrame(n)}))},m=(async()=>{if("undefined"==typeof browser)return;let{version:e}=await browser.runtime.getBrowserInfo();return Number(e.split(".")[0])})();var f=i(5510),x=i(8098),v=i(5693);const b=e=>Object.fromEntries(Object.entries(e).map((([e,t])=>[e,"string"==typeof t?(0,v.Z)(t):b(t)]))),y=b,w=y({help:"help",addSettingFor:"add_smart_setting_for_X",deleteSettingFor:"delete_smart_setting_for_X",editSmartSettings:"edit_smart_settings"}),k=(e,t)=>w[e].replace(/XXX/g,t);function _(){return o.dy`
  <style>
  ${d}
  :host{
    display: block;
    position: absolute;
    bottom: 40px;
    font-size: 12px;
    color: #28344f;
  }
  :host > .In{
    position: relative;
    border-radius: 3px;
    background: #fff;
    border: 1px solid #bcbcbc;
    box-shadow: 0 2px 3px 0 rgba(0, 0, 0, 0.35);
  }

  .Element{
    padding: 0 12px;
    line-height: 34px;
    white-space: nowrap;
    cursor: pointer;
    border-top-left-radius: 3px;
    border-top-right-radius: 3px;
    overflow: hidden;
    text-overflow: ellipsis;
  }
  .Element:hover{
    background: #28344f;
    color: #fff;
  }
  .Element ~ .Element{
    border-top: 1px solid #e6e6e6;
    border-top-left-radius: 0px;
    border-top-right-radius: 0px;
  }
  .Element:last-child{
    border-bottom-left-radius: 3px;
    border-bottom-right-radius: 3px;
  }
  </style>

  <div class="In">
  ${(()=>this.domain?this.containsFilter?o.dy`
    <div class="Element" @click="${this.removeFilter}">
      ${k("deleteSettingFor",this.unicodeDomain)}
    </div>`:o.dy`
    <div class="Element" @click="${this.addFilter}">
      ${k("addSettingFor",this.unicodeDomain)}
    </div>`:"")()}

  ${(()=>this.showEditSmartSettings?o.dy`
    <div class="Element" @click="${this.editSettings}">
      ${w.editSmartSettings}
    </div>`:"")()}
    <div class="Element" @click="${this.openHelp}">${w.help}</div>
  </div>`}var E=i(7185),C=i(7679);class $ extends((0,C.$)(E.Z)(o.oi)){render(){return _.call(this)}static get properties(){return{containsFilter:{type:Boolean},domain:{type:String},showEditSmartSettings:{type:Boolean},unicodeDomain:{type:String}}}constructor(){super(),this.containsFilter=null,this.domain="",this.unicodeDomain=""}async updated(e){if(e.has("domain")){if(!this.domain)return;this.unicodeDomain=x.ZP.toUnicode(this.domain)}}stateChanged({page:e}){const t=e.split(":");this.showEditSmartSettings="index"!==t[0]||"filters"!==t[1]}addFilter(){let{pac:{filters:e},user:{premium:t}}=E.Z.getStateSync();t||!e.length?E.Z.dispatch({type:"Page: set",page:"index:filters:"+this.domain}):this.showPremiumPopup(),this.remove()}editSettings(){(0,n.Z)({type:"сounters.increase",property:"popup: smart settings: open list"}),E.Z.dispatch({type:"Page: set",page:"index:filters"}),this.remove()}openHelp(){(0,n.Z)({type:"сounters.increase",property:"popup: smart settings: open help"}),(0,n.Z)({type:"create tab",options:"/pages/help/help.html"}),this.remove()}removeFilter(){f.Z.siteFilters.remove(this.domain),this.remove()}async showPremiumPopup(){const e=document.createElement("popup-premium-onerule");e.style.cssText="top:-100%;",document.body.append(e),p.Z.partial({category:"premium",action:"show"});const t=await m;if("number"==typeof t&&t<=62){const t=-100,i=0;await g({duration:800,action:o=>{const n=o*(i-t)+t;e.style.cssText=`top:${n}%;`}})}else{const t=e.animate([{top:"-100%"},{top:"0"}],{duration:800,easing:"linear"});await new Promise((e=>{t.onfinish=e}))}e.style.cssText=""}}customElements.define("context-menu",$);class S extends o.oi{constructor(){super(),this.bottom=0}render(){return o.dy`
    <style>
    ${d}
    :host{
      display:block;
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: rgba(0, 0, 0, 0.5);
    }

    :host > .In{
      position: absolute;
      bottom: ${this.bottom}px;
      left: 0;
      right: 0;
      text-align: center;
    }
    :host > .In > .In{
      text-align: left;
      display: inline-block;
      vertical-align: top;
    }
    .Text{
      font-size: 18px;
      font-weight: 600;
      text-align: center;
      color: #fff;
      margin-bottom: -12px;
    }
    .Arrow{
      background: url( '/images/tip_arrow.svg' ) 0 0 no-repeat;
      width: 50px;
      padding-top: 100px;
      height: 0;
      overflow: hidden;
      text-indent: -9999px;
      font-size: 0;
      margin-left: auto;
    }

    .Close{
      width: 16px;
      height: 16px;
      position: absolute;
      cursor: pointer;
      font-size: 0;
      right: 20px;
      top: 20px;
      transform: rotate(45deg)
    }
    .Close::before,
    .Close::after{
      content: '';
      display: block;
      position: absolute;
      background: #fff;
      overflow: hidden;
    }
    .Close::before{
      top: 0;
      left: calc( 50% - 1px );
      height: 100%;
      width: 2px;
    }
    .Close::after{
      left: 0;
      top: calc( 50% - 1px );
      width: 100%;
      height: 2px;
    }
    .Close:hover::before,
    .Close:hover::after{
      background: #ddd;
    }
    </style>

    <div class="In"><div class="In">
      <div class="Text">
        Click on this button<br/>
        to Start VPN
      </div>
      <div class="Arrow"></div>
    </div></div>
    <div class="Close" @click="${this.close}"></div>`}close(){this.dispatchEvent(new CustomEvent("close"))}}customElements.define("first-start-tips-button",S);class B extends o.oi{render(){return o.dy`
    <style>
    ${d}
    :host{
      display:block;
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: rgba(0, 0, 0, 0.5);
      color: #fff;
      text-align: center;
    }
    :host > .In{
      position: absolute;
      top: 55px;
      bottom: 40px;
      left: 0;
      width: 100%;
      display: flex;
      align-items: center;
    }
    :host > .In > .In{
      width: 300px;
      margin: 0 auto;
    }

    .Title{
      font-size: 18px;
      font-weight: 600;
    }
    .Text{
      padding-top: 25px;
    }

    .Close{
      width: 16px;
      height: 16px;
      position: absolute;
      cursor: pointer;
      font-size: 0;
      right: 20px;
      top: 20px;
      transform: rotate(45deg)
    }
    .Close::before,
    .Close::after{
      content: '';
      display: block;
      position: absolute;
      background: #fff;
      overflow: hidden;
    }
    .Close::before{
      top: 0;
      left: calc( 50% - 1px );
      height: 100%;
      width: 2px;
    }
    .Close::after{
      left: 0;
      top: calc( 50% - 1px );
      width: 100%;
      height: 2px;
    }
    .Close:hover::before,
    .Close:hover::after{
      background: #ddd;
    }
    </style>

    <div class="In"><div class="In">
      <div class="Title">
        Your VPN connection is now <br/>
        protected by Browsec
      </div>
      <div class="Text">
        You can visit any site now.<br/>
        All your traffic will route through our VPN server.
      </div>
    </div></div>
    <div class="Close" @click="${this.close}"></div>`}close(){this.dispatchEvent(new CustomEvent("close"))}}customElements.define("first-start-tips-protected",B);class L extends o.oi{render(){return o.dy`
    <style>
    ${d}
    :host{
      display: block;
      position: absolute;
    }
    :host > .Bg{
      position: absolute;
      top: 0px;
      right: 0px;
      bottom: 0px;
      left: 0px;
    }
    :host > .Bg::after{
      content: '';
      display: block;
      position: absolute;
      top:0px;left:0px;
      width: 100%;
      height: 100%;
      background: #28344f;
      border-radius: 4px;
      overflow: hidden;
      text-indent: -9999px;
    }
    :host > .Bg > .Corner{
      position: absolute;
      left: 16px;
      bottom: 100%;
      width: 10px;
      height: 5px;
      overflow: hidden;
    }
    :host > .Bg > .Corner::after{
      content: '';
      display: block;
      border: 5px solid transparent;
      border-bottom-color: #28344f;
      width: 0;
      height: 0;
      overflow: hidden;
      margin-top: -5px;
    }
    :host > .In{
      position: relative;
      padding: 5px 14px;
      color: #fff;
      font-size: 12px;
    }
    </style>

    <div class="Bg"><div class="Corner"></div></div>
    <div class="In">${this.text}</div>`}static get properties(){return{text:{type:String}}}constructor(){super(),this.text=""}}customElements.define("general-tooltip",L);const P=y({goBack:"go_back",signIn:"sign_in",signOut:"sign_out"});function I(){return o.dy`
  <style>
  ${d}
  :host{
    display: block;
    height: 56px;
    line-height: 56px;
    border: 1px solid #28344f;
    border-width: 0 5px 0 5px;
    background: #28344f;
    color: #fff;
    overflow: hidden;
    position: relative;
  }
  :host::after{
    content:' ';clear:both;display:block;width:0;height:0;overflow:hidden;font-size:0;
  }
  :host > .In{
    overflow: hidden;
    height: 100%;
    text-align: right;
  }

  .GoBack{
    cursor: pointer;
    display:inline-block;
    vertical-align:middle;
    position:relative;
    color:#b3becf;
    font-size:14px;
    text-decoration: underline;
    padding: 0 5px 0 18px;
    background: url( '/images/back_hover.svg' ) no-repeat 0 -5000px;
  }
  .GoBack:hover{
    color: white;
    text-decoration: none;
  }

  .GoBack::before{
    content:'';
    background: url( '/images/back.svg' ) no-repeat 50% 50%;
    background-size: 100% 100%;
    width: 13px;
    height: 13px;
    display: block;
    position: absolute;
    left: 0;
    top: 50%;
    margin-top: -6px;
  }
  .GoBack:hover::before{
    background-image: url( '/images/back_hover.svg' );
  }

  .LoginGuest{
    color: #fff;
    cursor: pointer;
    text-decoration: underline;
    display: inline-block;
    vertical-align: top;
    padding: 0 5px 0 5px;
  }
  .LoginGuest:hover{
    text-decoration: none;
  }

  .Logined{
    height: 24px;
    line-height: 24px;
    width: 100%;
    display:inline-block;
    vertical-align:top;
    vertical-align: middle;
  }
  .Logined::after{
    content:' ';clear:both;display:block;width:0;height:0;overflow:hidden;font-size:0;
  }

  .Logout{
    float: right;
    cursor: pointer;
    width: 20px;
    padding-top: 20px;
    overflow: hidden;
    height: 0;
    background: url( '/images/logout_grey.svg' ) 0 0 no-repeat;
    background-size: 100% 100%;
    border: 2px solid transparent;
    position: relative;
  }
  .Logout:hover{
    background-image: url( '/images/logout_white.svg' );
  }
  .Logout::after{
    content: '';
    display: block;
    position: absolute;
    top: 0;
    left: 0;
    width: 1px;
    height: 1px;
    overflow: hidden;
    background: url( '/images/logout_white.svg' ) 0 -5000px no-repeat;
  }

  .Mail{
    vertical-align: middle;
    padding: 0 8px 0 5px;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }
  </style>

  <head-logo .premium="${this.user.premium}"></head-logo>
  <div class="In">
  ${(()=>this.indexPage?this.user.email?o.dy`
    <div class="Logined">
      <div class="Logout" @click="${this.logout}" title="${P.signOut}"></div>
      <div class="Mail" title="${this.user.email}">${this.user.email}</div>
    </div>`:o.dy`
      <div class="LoginGuest" @click="${this.login}">
        ${P.signIn}
      </div>`:o.dy`
      <div class="GoBack" @click="${this.back}">${P.goBack}</div>`)()}
  </div>`}class T extends o.oi{render(){return o.dy`
    <style>
    ${d}
    :host{
      display: block;
      padding: 5px 5px 0 5px;
      float: left;
    }

    :host > .In{
      display: table;
    }
    :host > .In > .L{
      display: table-cell;
      vertical-align: middle;
    }
    :host > .In > .R{
      display: table-cell;
      vertical-align: middle;
      padding-left: 10px;
    }

    .Ball{
      background: url( '/images/logo_ball.svg' ) 0 0 no-repeat;
      background-size: 100% 100%;
      width: 46px;
      padding-top: 46px;
      height: 0;
      overflow: hidden;
    }

    .Premium,
    .NoPremium{
      height: 0;
      overflow: hidden;
    }
    .Premium{
      background: url( '/images/logo_text_premium.svg' ) 0 0 no-repeat;
      background-size: 100% 100%;
      width: 85px;
      padding-top: 29px;
    }
    .NoPremium{
      background: url( '/images/logo_text.svg' ) 0 0 no-repeat;
      background-size: 100% 100%;
      width: 85px;
      padding-top: 14px;
    }

    img{
      display: block;
    }
    </style>

    <div class="In">
      <div class="L"><div class="Ball"></div></div>
      <div class="R">
        <div class="${this.premium?"Premium":"NoPremium"}"></div>
      </div>
    </div>`}static get properties(){return{premium:{type:Boolean}}}constructor(){super(),this.premium=!1}}customElements.define("head-logo",T);class Z extends((0,C.$)(E.Z)(o.oi)){render(){return I.call(this)}static get properties(){return{user:{type:Object},indexPage:{type:Boolean}}}stateChanged({user:e,page:t}){this.user=e,this.indexPage="index"===t.split(":")[0]}constructor(){super(),this.user={type:"guest",premium:!1},this.indexPage=!0}back(){E.Z.dispatch({type:"Page: set",page:"index:home"})}login(){E.Z.dispatch({type:"Page: set",page:"login"})}logout(){a()}}customElements.define("main-head",Z);const z=class{constructor(){this.listeners=[],this.word="",this.keydownListener=this.keydownListener.bind(this)}addChar(e){let t=this.word,i=performance.now();(!this.lastTimestamp||i-this.lastTimestamp>700)&&(t=""),t+=e,this.lastTimestamp=i,t!==this.word&&(this.word=t,this.listeners.forEach((e=>{e(t)})))}addListener(e){this.listeners.push(e)}removeListener(e){this.listeners=this.listeners.filter((t=>t!==e))}keydownListener(e){let{code:t,key:i}=e;" "===i&&e.preventDefault();let o=t?t.replace(/^key/i,""):i;"Space"===o&&(o=" "),o&&1===o.length&&/[ a-z]/i.test(o)&&(o=o.toLowerCase(),this.addChar(o))}},D=y({browsecOff:"browsec_off",off:"off"});function O(){return o.dy`
  <style>
  ${d}
  :host{
    display: block;
    overflow: auto;
    position: absolute;
    background: #fff;
    border: 1px solid #bcbcbc;
    padding: 4px 0;
    box-shadow: 0 4px 16px rgba(0, 0, 0, 0.2);
    box-sizing: border-box;
  }

  .E{
    padding: 4px 10px;
    cursor: pointer;
    user-select: none;
  }
  .E.highlighted{
    background: #f5f5f5;
  }
  .E > .In{
    display: table;
    width: 100%;
  }

  .Name{
    display: table-cell;
    vertical-align: middle;
  }
  .Flag{
    display: table-cell;
    vertical-align: middle;
    padding-left: 10px;
    width: 1px;
  }
  .Flag img{
    display: block;
    border-radius: 4px;
    filter: saturate(135%);
    opacity:0.7;
    border: 1px solid rgba(0, 0, 0, 0.22);
  }
  .Flag_Off{
    width: 30px;
    line-height: 20px;
    font-size: 14px;
    color: #994136;
    text-align: center;
  }

  .Off{
    padding-bottom: 10px;
    margin-bottom: 10px;
    border-bottom: 1px solid #cccccc;
  }
  </style>

  <div class="Off">
    <div
      class="E${null===this.country?" highlighted":""}"
      @click="${this.offClick}"
      @mousemove="${this.elementHighlight(null)}">
      <div class="In">
        <div class="Name">${D.browsecOff}</div>
        <div class="Flag"><div class="Flag_Off">${D.off}</div></div>
      </div>
    </div>
  </div>
  ${this.countries.map((e=>{return o.dy`
    <div
      class="E${this.country===e.code?" highlighted":""}"
      @click="${this.elementClick(e.code)}"
      @mousemove="${this.elementHighlight(e.code)}">
      <div class="In">
        <div class="Name">${e.name}</div>
        <div class="Flag">
          <img src="${t=e.code,"usw"===t&&(t="us"),"uk"===t&&(t="gb"),t?`/images/flags/${t}.svg`:"/images/empty.png"}" width="30" height="20" alt=""/>
        </div>
      </div>
    </div>`;var t}))}`}class A extends o.oi{render(){return O.call(this)}static get properties(){return{countries:{type:Array},country:{type:String}}}constructor(){super(),this.keydownListener=this.keydownListener.bind(this),this.countries=[],this.country=null}connectedCallback(){super.connectedCallback(),this.charsBuffer=new z,document.addEventListener("keydown",this.keydownListener)}firstUpdated(){var e,t,i;let o=this.countries.map((({code:e,name:t})=>({code:e,name:t.toLowerCase()})));const n=null===(e=this.shadowRoot)||void 0===e?void 0:e.children,s=[];for(const e of n)"div"===e.tagName.toLowerCase()&&s.push(e);this.namesList=s.slice(1).map(((e,t)=>{let{code:i,name:n}=o[t];return{element:e,code:i,name:n}})),this.namesList.unshift({code:null,element:null===(t=this.shadowRoot)||void 0===t||null===(i=t.querySelector)||void 0===i?void 0:i.call(t,"div.Off > div.E"),name:"OFF"}),this.charsBuffer.addListener((e=>{const t=this.namesList.find((({code:t,name:i})=>t&&i.startsWith(e)));if(!t)return;const{element:i,code:o}=t;this.country=o,this.scrollTop=i.offsetTop-2}))}disconnectedCallback(){super.disconnectedCallback(),document.removeEventListener("keydown",this.keydownListener)}elementClick(e){return()=>{this.dispatchEvent(new CustomEvent("select",{detail:e})),this.remove()}}elementHighlight(e){return t=>{Boolean(t.movementX||t.movementY)&&(this.country=e)}}keydownListener(e){let{key:t}=e;if("ArrowDown"!==t&&"ArrowUp"!==t){if("Enter"===t)return this.country?this.dispatchEvent(new CustomEvent("select",{detail:this.country})):this.dispatchEvent(new CustomEvent("disable")),void this.remove();this.charsBuffer.keydownListener(e)}else{e.preventDefault();let i=(()=>{let e=this.namesList.length,i=this.namesList.findIndex((({code:e})=>e===this.country));return i+="ArrowDown"===t?1:-1,(i+e)%e})(),o=this.namesList[i];this.country=o.code;let n=this.scrollTop,s=this.offsetHeight,r=n+s,a=o.element.offsetHeight,l=o.element.offsetTop,c=l+a;if(l>=n&&c<=r)return;let d=l>=n?c-s+2:l-2;this.scrollTop=d}}offClick(){this.dispatchEvent(new CustomEvent("disable")),this.remove()}}customElements.define("filters-country-list",A);var N=i(1031);const F=({action:e=(e=>e),url:t,storeState:i})=>(0,N.Z)(t,(t=>Object.assign(e(t),{instd:i.daysAfterInstall})));var R=i(6194);function M(){return o.dy`
  <style>
  ${d}
  @keyframes rotating {
    from {
      transform: rotate(0deg);
    }
    to {
      transform: rotate(360deg);
    }
  }

  a:hover{
    text-decoration: none;
  }

  :host{
    display: block;
  }

  .Login{
    padding: 38px 12px 2px;
    font-size: 14px;
    min-height: 140px;
    height: 318px;
    font-size: 11px;
  }

  .Title{
    font-size: 20px;
    font-weight: 500;
    text-align: center;
  }
  .Title::after{
    display: block;
    content: '';
    width: 100px;
    margin: 0 auto;
    overflow:hidden;font-size:0;text-indent:-9999px;height:0;
    padding-top:20px;
    border-bottom: 4px solid #3d973f;
  }

  .Notice {
    position: absolute;
    font-size: 13px;
    color: #090;
    top: -24px;
    width: 100%;
    left: -2px;
  }
  .Error {
    position: absolute;
    bottom: calc(100% + 6px);
    left: 20px;
    right: 20px;
    font-size: 13px;
    color: #900;
    text-align: center;
  }

  .Login input[type="text"],
  .Login input[type="password"] {
    font:100% arial,sans-serif;
    vertical-align:middle;
    outline:none;
    width: 315px;
    margin: 1px 0px;
    height: 36px;
    border-radius: 5px;
    padding: 1px 10px;
    font-size: 15px;
    outline: none;
    background: #f5f5f5;
    border: 1px #7b7c80 solid;
    color: #1c304e;
  }
  .Login input[type="text"]::placeholder,
  .Login input[type="password"]::placeholder {
    color: #9b9c9e;
  }
  .Login input[type="text"].invalid,
  .Login input[type="password"].invalid{
    border: 1px solid #900;
  }
  .Login input[type="text"].invalid:focus,
  .Login input[type="password"].invalid:focus{
    outline: none;
  }

  .Login_Form{
    margin:0;
    padding:0;
    border-style:none;
    margin-top: 46px;
    text-align: center;
    padding: 0 20px;
    position:relative;
  }

  .Login_Row{
    width:100%;
    padding: 0 0 14px;
  }
  .Login_Row::after{
    display:block;
    clear:both;
    content:'';
  }
  .Login_Row label{
    box-sizing: border-box;
    display: inline-block;
    min-width: 100px;
    padding: 6px 5px 0 0;
  }

  .Login_ForgotPassword {
    color: #1c304e;
    font-size: 12px;
    line-height: 1;
    margin-top: 3px;
    float: right;
  }

  .Login_Button{
    margin-top: 18px;
  }
  .Login_Button > .In{
    display: inline-block;
    vertical-align: top;
    position: relative;
  }
  .Login_Button.loading > .In::after{
    content: '';
    display: block;
    position: absolute;
    left: 12px;
    top: calc(50% - 12px);
    width: 24px;
    padding-top: 24px;
    overflow: hidden;
    height: 0;
  }
  .Login_Button_Overlay{
    display: none;
    position: absolute;
    left: 9px;
    top: calc(50% - 15px);
    width: 24px;
    padding-top: 24px;
    height: 0;
    overflow: hidden;
    background:
      #fff radial-gradient(circle at 80% 80%, #1c304e 0, #1c304e 13%, transparent 90%, transparent 100%);
    border-radius: 50%;
    border: 3px solid #1c304e;
    animation: rotating 1.2s linear infinite;
  }
  .Login_Button.loading .Login_Button_Overlay{
    display: block;
  }
  .Login_Button_Overlay::after{
    content: '';
    display: block;
    position: absolute;
    width: 16px;
    padding-top: 16px;
    height: 0;
    overflow: hidden;
    top: calc( 50% - 16px / 2 );
    left: calc( 50% - 16px / 2 );
    background: #1c304e;
    border-radius: 50%;
  }

  .Login_Button button{
    box-sizing: border-box;
    display: inline-block;
    border: 0;
    border-radius: 5px;
    position:relative;
    background-color: #1c304e;
    color:#fff;
    text-align:center;
    font-family: inherit;
    font-weight: 400;
    padding: 2px 12px;
    font-size: 18px;
    line-height: 30px;
    height: 45px;
    cursor:pointer;
    min-width: 190px;
  }

  .Login_Register {
    margin-top: 7px;
    font-size: 12px;
  }
  .Login_Register a {
    color: #1c304e;
  }
  </style>

  <div class="Login">
    <div class="Title">${this.translations.signIn}</div>
    <form class="Login_Form" action="#" @submit="${this.formSubmit}">

    ${(()=>this.notice?o.dy`<div class="Notice">${this.notice}</div>`:"")()}
    ${(()=>this.error?o.dy`<div class="Error"></div>`:"")()}

      <div class="Login_Row">
        <input class="${this.error?"invalid":""}" type="text" size="30" name="email" autofocus placeholder="${this.translations.email}">
      </div>
      <div class="Login_Row">
        <input class="${this.error?"invalid":""}" type="password" size="30" name="password" placeholder="${this.translations.password}">
        <a href="${this.links.resetPassword}" class="Login_ForgotPassword" target="_blank">
          ${this.translations.forgotYourPassword}
        </a>
      </div>

      <div class="Login_Row">
        <div class="Login_Button${this.loading?" loading":""}"><div class="In">
          <button>${this.translations.logIn}</button>
          <div class="Login_Button_Overlay"></div>
        </div></div>

        <div class="Login_Register">
          ${this.translations.dontHaveAnAccount}
          <a href="${this.links.signUp}" target="_blank">
            ${this.translations.signUp}
          </a>
        </div>
      </div>
    </form>
  </div>`}let H=y({dontHaveAnAccount:"dont_have_an_account",email:"email",forgotYourPassword:"forgot_your_password",logIn:"log_in",password:"password",signIn:"sign_in",signUp:"sign_up",welcomeBack:"welcome_back",errors:{incorrectEmailOrPassword:"incorrect_email_or_password",noConnection:"authentication_error_no_connection",thisAccountIsLocked:"this_account_is_locked_please_contact_us"}});class V extends((0,C.$)(E.Z)(o.oi)){render(){return M.call(this)}static get properties(){return{links:{type:Object},loading:{type:Boolean},translations:{type:Object},error:{type:Boolean},notice:{type:String}}}get links(){const e=E.Z.getStateSync();return{resetPassword:F({url:R.Z.resetPassword,storeState:e}),signUp:F({url:R.Z.newUser,storeState:e})}}get translations(){return H}constructor(){super(),this.loading=!1,this.error=!1}firstUpdated(e){var t,i;super.firstUpdated(e);const o=e=>{var t,i;return null===(t=this.shadowRoot)||void 0===t||null===(i=t.querySelector)||void 0===i?void 0:i.call(t,e)},n=o('input[type="text"][name="email"]'),s=o('input[type="password"][name="password"]');if(!n||!s)throw new Error("No input elements in main-login");this.elements={mail:n,password:s};const r=null===(t=this.shadowRoot)||void 0===t||null===(i=t.querySelectorAll)||void 0===i?void 0:i.call(t,"a");for(const e of r)e.addEventListener("click",(async()=>{var e;await new Promise((e=>{setTimeout(e,50)})),(null===(e=self)||void 0===e?void 0:e.close)&&self.close()}));this.elements.mail.focus()}async formSubmit(e){if(e.preventDefault(),this.loading)return;if(this.loading=!0,this.errorView){Array.from(this.errorView.childNodes).forEach((e=>{this.errorView.removeChild(e)}))}this.error=!1,this.notice=null;let t=this.elements.mail.value,i=this.elements.password.value;try{await r({email:t,password:i}),this.notice=H.welcomeBack,(async()=>{var e,t;await this.requestUpdate();let i=null===(e=this.shadowRoot)||void 0===e||null===(t=e.querySelector)||void 0===t?void 0:t.call(e,"div.Notice");if(!i)throw new Error("No notiveCiew in main-login");i.style.cssText="opacity: 0";let o=i.animate([{opacity:0},{opacity:1}],{duration:200,easing:"linear"});await new Promise((e=>{o.onfinish=e})),i.style.cssText=""})(),await new Promise((e=>{setTimeout(e,1e3)})),E.Z.dispatch({type:"Page: set",page:"index:home"})}catch(e){var o,n;let{status:t,responseText:i}=e,s={};try{i&&(s=JSON.parse(i))}catch(e){}let r=401!==t?"noConnection":8===s.error_code?"thisAccountIsLocked":"incorrectEmailOrPassword",a=H.errors[r];this.error=!0,401===t&&(this.elements.password.value=""),await this.requestUpdate();let l=null===(o=this.shadowRoot)||void 0===o||null===(n=o.querySelector)||void 0===n?void 0:n.call(o,"div.Error");if(!l)throw new Error("No errorView in main-login");this.errorView=l;a.split(/\n/g).flatMap(((e,t,i)=>{let o=[];return e.trim()&&o.push(document.createTextNode(e)),t!==i.length-1&&o.push(document.createElement("br")),o})).forEach((e=>{this.errorView.appendChild(e)}));this.errorView.style.cssText="opacity: 0";let c=this.errorView.animate([{opacity:0},{opacity:1}],{duration:200,easing:"linear"});await new Promise((e=>{c.onfinish=e})),this.errorView.style.cssText=""}this.loading=!1}onAnimationComplete(){this.elements.mail.focus()}}customElements.define("main-login",V);var U=i(9328);const W=y({help:"help"});function q(){return o.dy`
  <style>
  ${d}
  .Foot{
    height: 38px;
    padding: 0 10px;
    border-top: 1px solid #bcbcbc;
    background: #f5f5f5;
    position: absolute;
    right:0px;bottom:0px;left:0px;
  }
  .Foot::after{
    content:' ';
    display:block;
    clear:both;
    width:0;height:0;
    overflow:hidden;
    font-size:0;
  }
  .Foot c-switch{
    margin: 7px 0 0;
    float: right;
  }

  .Switch{
    position: absolute;
    top:0px;bottom:38px;left:0px;
    width: 100%;
    white-space: nowrap;
  }
  .Switch > *{
    display:inline-block;
    vertical-align:top;
    width: 100%;
    height: 100%;
    position: relative;
    overflow: hidden;
    white-space: normal;
  }

  .Help{
    float: right;
    position: relative;
    margin-top: 12px;
    padding-left: 19px;
    cursor: pointer;
    font-size: 12px;
    line-height: 18px;
    color: #3b9946;
    background: url( '/images/menu/help_green.svg' ) 0 -5000px no-repeat;
  }
  .Help::after{
    content: '';
    display: block;
    position: absolute;
    left: 0;
    top: 50%;
    margin-top: -7px;
    background: url( '/images/menu/help_grey.svg' ) 0 0 no-repeat;
    background-size: 100% 100%;
    width: 14px;
    padding-top:14px;
    overflow:hidden;font-size:0;text-indent:-9999px;height:0;
  }
  .Help:hover::after{
    background-image: url( '/images/menu/help_green.svg' );
  }
  </style>

  <div class="Switch"></div>

  <div class="Foot">
  ${(()=>"help"===this.preMenuView?o.dy`
    <div class="Help" @click="${this.openHelp}">${W.help}</div>`:"switch"===this.preMenuView?o.dy`
    <c-switch @click="${this.switchClick}" .on="${this.switchOn}"></c-switch>`:"")()}
    <index-menu></index-menu>
  </div>`}const j=({defaultCountry:e,country:t,countries:i})=>{let o=i.includes(t)?t:e;return"usw"===o&&(o="us"),"uk"===o&&(o="gb"),`/images/flags/${o}.svg`},X=c().proxy.defaultCountry||"nl";function G(e){return o.dy`
  <style>
  ${d}
  .Off{
    width: 30px;
    line-height: 22px;
    padding-left: 1px;
    color: #994136;
    font-size: 14px;
    text-align: center;
  }

  .ChangeRule_Country{
    position: relative;
    width: 56px;
    border: 1px solid #bcbcbc;
    height: 22px;
    border-radius: 4px;
    padding: 1px 2px;
    background: url( '/images/smart_settings/arrow_up.svg' ) 0 -5000px no-repeat;
  }
  .ChangeRule_Country img{
    display: block;
    border-radius: 4px;
    filter: saturate(135%);
    opacity:0.7;
    border: 1px solid rgba(0, 0, 0, 0.22);
  }
  .ChangeRule_Country::after{
    content: '';
    display: block;
    background: url( '/images/smart_settings/arrow_down.svg' ) 0 0 no-repeat;
    background-size: 100% 100%;
    width: 9px;
    overflow:hidden;font-size:0;text-indent:-9999px;height:0;
    padding-top: 5px;
    position: absolute;
    top: 50%;
    right: 8px;
    margin-top: -2px;
  }
  .ChangeRule_Country.open{
    border-color: #3b9946;
  }
  .ChangeRule_Country.open::after{
    background-image: url( '/images/smart_settings/arrow_up.svg' );
    /* margin-top: -3px; */
  }

  .ChangeRule_Button{
    width: 46px;
    overflow:hidden;font-size:0;text-indent:-9999px;height:0;
    padding-top:24px;
    background: #3b9946 url( '../images/smart_settings/agree_white.svg' ) 0 -5000px no-repeat;
    border-radius: 4px;
    cursor: pointer;
    position: relative;
  }
  .ChangeRule_Button::after{
    content: '';
    display: block;
    width: 14px;
    overflow: hidden;
    font-size:0;
    text-indent: -9999px;
    height: 0;
    padding-top:14px;
    position: absolute;
    top: 50%;
    left: 50%;
    margin: -7px 0 0 -7px;
    background: url( '/images/smart_settings/plus_white.svg' ) 0 0 no-repeat;
    background-size: 100% 100%;
  }
  .ChangeRule_Button.save::after{
    width: 16px;
    padding-top: 11px;
    background-image: url( '/images/smart_settings/agree_white.svg' );
    margin: -5px 0 0 -8px;
  }

  .List{
    position: absolute;
    top:65px;
    right:0px;
    bottom:0px;
    left:0px;
    overflow: auto;
    background: url( '/images/smart_settings/trash_green.svg' ) 0 -5000px no-repeat;
  }
  .List > .E{
    position: relative;
    line-height: 34px;
    transition: opacity 0.2s;
  }
  .List > .E:hover{
    background: #fafafa;
  }
  .List > .E.active,
  .List > .E.active:hover{
    background: #f5f5f5;
  }
  .List > .E.inactive,
  .List > .E.inactive:hover{
    background: transparent;
    opacity: 0.33;
  }
  .List > .E.inactive.disabled,
  .List > .E.inactive.disabled:hover{
    background: transparent;
    opacity: 1;
  }
  .List > .E > .In{
    padding: 0 7px 0 14px;
    cursor: pointer;
    height: 34px;
  }
  .List > .E > .In::after{
    content:' ';clear:both;display:block;width:0;height:0;overflow:hidden;font-size:0;
  }

  .List_Remove{
    float: right;
    background: url( '/images/smart_settings/trash_grey.svg' ) 0 0 no-repeat;
    background-size: 100% 100%;
    width: 11px;
    overflow:hidden;font-size:0;text-indent:-9999px;height:0;
    padding-top:14px;
    margin: 3px 0 0 6px;
    cursor: pointer;
    border: 7px solid transparent;
  }
  .List_Remove:hover{
    background-image: url( '/images/smart_settings/trash_green.svg' );
  }
  .List_Flag{
    float: right;
    width: 30px;
    padding: 7px 0 0 13px;
  }
  .List_Flag img{
    display: block;
    border-radius: 4px;
    filter: saturate(135%);
    opacity:0.7;
    border: 1px solid rgba(0, 0, 0, 0.22);
  }

  .ChangeRule{
    padding: 19px 14px;
    border-bottom: 1px solid #bcbcbc;
    display: flex;
    align-items: center;
  }
  .ChangeRule > .E{
    flex-grow: 0;
    flex-shrink: 0;
  }
  .ChangeRule > .E ~ .E{
    padding-left: 10px;
  }
  .ChangeRule > .E.input{
    flex-grow: 1;
  }

  .List_Favicon{
    width: 16px;
    float: left;
    padding: 9px 7px 0 0;
    transition: opacity 0.2s;
  }
  .List > .E.disabled .List_Favicon{
    opacity: 0.3;
  }
  .List_Favicon img{
    display: block;
  }

  .List_Name{
    overflow: hidden;
    white-space: nowrap;
    text-overflow: ellipsis;
    transition: opacity 0.2s;
  }
  .List > .E.disabled .List_Name{
    opacity: 0.3;
  }

  .List_Deleted{
    display: none;
    background: #fff;
    position: absolute;
    top:0px;right:0px;bottom:0px;left:0px;
    padding: 0 14px 0 22px;
    border-left: 14px solid transparent;
    color: #3b9946;
  }
  .List_Deleted::after{
    content: '';
    width: 12px;
    overflow:hidden;font-size:0;text-indent:-9999px;height:0;
    padding-top:12px;
    background: url('/images/smart_settings/check.svg') 0 0 no-repeat;
    background-size: 100% 100%;
    position: absolute;
    left: 0;
    top: 50%;
    margin-top: -6px;
  }
  .List > .E.deleted .List_Deleted{
    display: block;
  }

  .List_Delete_Link{
    cursor: pointer;
    color: #28344f;
    border-bottom: 1px dashed #28344f;
  }
  .List_Delete_Link:hover{
    border-bottom-color: transparent;
  }

  .List_Select{
    float: right;
    padding: 4px 0 0 5px;
  }
  .List_Select_Button{
    line-height: 24px;
    white-space: nowrap;
    cursor: pointer;
    border: 1px solid #3b9946;
    color: #3b9946;
    padding: 0 8px;
    border-radius: 4px;
    font-size: 12px;
  }
  .List_Select_Button:hover{
    background: #3b9946;
    color: #fff;
  }

  .List_InactiveOverlay{
    display: none;
    position: absolute;
    top: 0px;
    right: 0px;
    bottom: 0px;
    left: 0px;
    overflow: hidden;
    text-indent: -9999px;
  }
  .List > .E.inactive .List_InactiveOverlay{
    display: block;
  }
  </style>

  <div class="ChangeRule">
    <div class="E text">${e.on}</div>
    <div class="E input">
      <filters-domain
        .value="${this.domain}"
        @save="${this.save}"
        @value-changed="${this.inputListener}"
      ></filters-domain>
    </div>
    <div class="E text">${e.use}</div>
    <div class="E flag">
      <div 
        data-role="country selector"
        class="ChangeRule_Country" 
        @click="${this.openCountryList}"
      >
      ${(()=>{if(!this.country)return o.dy`
          <div class="Off">${e.off}</div>`;const t=j({countries:this.countries,country:this.country,defaultCountry:X});return o.dy`
          <img src="${t}" width="30" height="20" alt=""/>`})()}
      </div>
    </div>
    <div class="E button">
      <div 
        class="ChangeRule_Button${this.selectedDomain?" save":""}" 
        @click="${this.save}"
      ></div>
    </div>
  </div>

  <div class="List" @click="${this.listClick}">
  ${this.filters.map((t=>{return o.dy`
    <div class="E ${(({deleted:e,disabled:t,value:i},o)=>{let n=[];return e&&n.push("deleted"),t&&n.push("disabled"),o&&n.push(i===o?"active":"inactive"),n.join(" ")})(t,this.selectedDomain)}">
      <div class="In" @click="${this.listElementClick(t)}">
        <div class="List_Remove" title="${e.removeSmartSetting}"></div>
        ${(()=>t.disabled?o.dy`
        <div class="List_Select">
          <div class="List_Select_Button">${e.select}</div>
        </div>`:o.dy`
        <div class="List_Flag">
    ${(()=>{if(!t.country)return o.dy`
          <div class="Off">${e.off}</div>`;const i=j({countries:this.countries,country:t.country,defaultCountry:X});return o.dy`
          <img src="${i}" width="30" height="20" alt=""/>`})()}
        </div>`)()}
        <div class="List_Favicon">
          <img src="${i=t.value,i?"https://www.google.com/s2/favicons?domain="+i:"/images/empty.png"}" width="16" height="16" alt=""/>
        </div>
        <div class="List_Name">${t.view}</div>
      </div>
      <div class="List_Deleted">
        ${e.settingWasDeleted}
        <span class="List_Delete_Link" @click="${this.cancelRemove(t)}">
          ${e.undo}
        </span>
      </div>
      <div class="List_InactiveOverlay" @click="${this.resetSelection}">&nbsp;</div>
    </div>`;var i}))}
  </div>`}const Y=y({pleaseEnterDomain:"please_enter_domain"});class J extends HTMLElement{render(){const e=this.shadowRoot,t=document.createElement("style");t.textContent=`\n    ${d}\n    :host{\n      display: block;\n    }\n\n    input[type="text"]{\n      display: block;\n      width: 100%;\n      border: 1px solid #bcbcbc;\n      line-height: 24px;\n      height: 24px;\n      box-sizing: border-box;\n      padding: 0 8px;\n      border-radius: 4px;\n      outline: none;\n    }\n    input[type="text"]:focus{\n      border-color: #28344f;\n    }`;const i=document.createElement("input");i.type="text",i.placeholder=Y.pleaseEnterDomain,i.addEventListener("input",(({target:e})=>{let{value:t}=e;t=t.replace(/\s+/g,"").toLowerCase();const o=i.selectionEnd;i.value=t;const n=o>t.length?t.length:o;i.setSelectionRange(n,n),this.inputValue=t,this._value=t,this.dispatchEvent(new CustomEvent("value-changed",{detail:{value:t}}))})),i.addEventListener("paste",(e=>{e.stopPropagation(),e.preventDefault();const t=(e.clipboardData||window.clipboardData).getData("text/plain").trim();if(!t)return;let i;try{i=new URL(t).hostname}catch(e){i=t.toLowerCase()}this._value=i,this.dispatchEvent(new CustomEvent("value-changed",{detail:{value:i}}))})),i.addEventListener("keypress",(e=>{let{code:t,which:o}=e;"Enter"!==t&&13!==o||(e.preventDefault(),this.dispatchEvent(new CustomEvent("save")),i.blur())})),this.input=i,e.append(t,i)}constructor(){super(),this._value="",this.inputValue="",this.attachShadow({mode:"open"}),this.render()}get value(){return this._value}set value(e){e!==this._value&&(this.inputValue=e,this._value=e,this.input.value=e)}}customElements.define("filters-domain",J);const{_:K}=self,Q="undefined"!=typeof browser?browser:chrome,ee=y({cancelEditing:"cancel_editing",off:"off",on:"on",pleaseEnterDomain:"please_enter_domain",pleaseEnterValidDomain:"please_enter_valid_domain",removeSmartSetting:"remove_smart_setting",select:"select",settingWasDeleted:"setting_was_deleted",thisDomainAlreadyInList:"this_domain_already_in_list",undo:"undo",use:"use"}),te=({view:e},{view:t})=>e<t?-1:e>t?1:0,ie=({dimensionElement:e,text:t})=>{const i=document.createElement("tooltip-error");i.text=t;const o=e.getBoundingClientRect(),n=o.top+e.offsetHeight-1;i.style.cssText=`top:${n}px;left:${o.left}px;`,document.body.append(i);const s=(()=>{let e=!0;return()=>{e?e=!1:(i.remove(),document.removeEventListener("click",s))}})();document.addEventListener("click",s)};class oe extends((0,C.$)(E.Z)(o.oi)){render(){return G.call(this,ee)}static get properties(){return{country:{type:String},countries:{type:Array},domain:{type:String},filters:{type:Array},premium:{type:Boolean},selectedDomain:{type:String}}}constructor(){super(),this.countries=[],this.country=null,this.domain="",this.filters=[],this.premium=null,this.selectedDomain=null}disconnectedCallback(){var e;super.disconnectedCallback(),null===(e=this.removeStoreListener)||void 0===e||e.call(this),delete this.removeStoreListener,this.documentClick&&document.removeEventListener("mousedown",this.documentClick)}async firstUpdated(e){super.firstUpdated(e);const t=this.shadowRoot,i=t.querySelector("div.List");if(!i)throw new Error("No list element in index-filters");this.nodes={list:i};{const e=[];for(const t of E.Z.getStateSync().pac.filters){if("domain"!==t.format)continue;const i=t.proxyMode?t.country:null,{disabled:o,value:n}=t,s=x.ZP.toUnicode(n);e.push({country:i,deleted:!1,disabled:o,value:n,view:s})}this.filters=e.sort(te)}const o=t.querySelector("div.ChangeRule filters-domain");if(!o)throw new Error("No domainInput element in index-filters");this.domainInput=o;const n=t.querySelector('[data-role="country selector"]');if(!n)throw new Error("No countryElement element in index-filters");this.countryElement=n,this.removeStoreListener=E.Z.onChange((({pac:{filters:e}})=>e),(async(e,t,i)=>{if(e.length===t.length)return;const o=e.length>t.length?"addition":"deletion";if("addition"===o){const i=K.differenceBy(e,t,K.isEqual)[0];if(!i)return;if(this.filters.some((({value:e})=>e===i.value)))return;let o=K.cloneDeep(this.filters);if("string"!=typeof i.value)throw new Error("Addition error for index-filters, not string provided before punicode");let n=x.ZP.toUnicode(i.value);return o.push({country:i.country,deleted:!1,value:i.value,view:n}),void(this.filters=o.sort(te))}if("deletion"===o){if(!Boolean(i.user.email)&&!e.length&&t.length-e.length>=2)return void(this.filters=[]);const o=K.differenceBy(t,e,K.isEqual)[0];if(!o)return;if(!this.filters.some((({deleted:e,value:t})=>t===o.value&&!e)))return;const n=K.cloneDeep(this.filters).filter((({value:e})=>e!==o.value));this.filters=n}}))}stateChanged({proxyServers:e,user:t}){this.countries=Array.from(t.premium?e.premiumCountries():e.freeCountries()),this.premium=t.premium}cancelRemove({country:e,value:t}){return()=>{if(this.filters.some((({deleted:e,disabled:t})=>!e&&!t))&&!E.Z.getStateSync().user.premium)return void this.showPremiumPopup();let i=K.cloneDeep(this.filters);const o=i.find((e=>e.value===t));o&&(o.deleted=!1),this.filters=i;const n={domain:t,type:e?"proxy":"direct"};e&&(n.country=e),f.Z.siteFilters.add(n)}}inputListener({detail:{value:e}}){this.domain=e}listClick({target:e}){}listElementClick({country:e,disabled:t,value:i,view:o}){return({target:s})=>{if(s instanceof HTMLElement){if(s.classList.contains("List_Remove")){const e=K.cloneDeep(this.filters),t=e.find((e=>e.value===i));return t&&(t.deleted=!0),this.filters=e,f.Z.siteFilters.remove(i),void this.resetSelection()}if(s.classList.contains("List_Select_Button")){{const e=K.cloneDeep(this.filters);{const t=e.find((({disabled:e})=>!e));t&&(t.disabled=!0)}{const t=e.find((({value:e})=>i===e));t&&delete t.disabled}this.filters=e}(0,n.Z)({type:"select disabled site filter",value:i})}else t?this.resetSelection():(this.country=e,this.domain=o,this.selectedDomain=i)}}}openCountryList(){this.countryElement.classList.add("open");const e=document.createElement("filters-country-list");e.countries=this.countries.map((e=>({code:e,name:Q.i18n.getMessage("country_name_"+e.toUpperCase())}))).sort((({name:e},{name:t})=>e<t?-1:e>t?1:0)),e.country=this.country,e.addEventListener("select",(({detail:e})=>{this.country=e,this.countryElement.classList.remove("open")})),e.addEventListener("disable",(()=>{this.country=null,this.countryElement.classList.remove("open")}));const{left:t,top:i}=this.countryElement.getBoundingClientRect(),o=this.countryElement.offsetHeight,n=i+o,s=window.innerWidth-t-this.countryElement.offsetWidth,r=window.innerHeight-i-o;e.style.cssText=`top:${n}px;right:${s}px;max-height:${r}px;`,document.body.append(e),this.documentClick=({target:t})=>{t instanceof HTMLElement&&(e.contains(t)||t===e)||(e.remove(),this.documentClick&&(document.removeEventListener("mousedown",this.documentClick),delete this.documentClick,this.countryElement.classList.remove("open")))},document.addEventListener("mousedown",this.documentClick)}resetSelection(){this.country=null,this.domain="",this.selectedDomain=null}async save(){const e=this.domain;if(!e)return void ie({dimensionElement:this.domainInput,text:ee.pleaseEnterDomain});const t=x.ZP.toASCII(e);if(void 0!==t)if(1!==t.split(".").length){{const e=t.split("."),i=4===e.length&&e.every((e=>/^[0-9]+$/.test(e)&&Number(e)>=0&&Number(e)<=255));if(!i&&e.some((e=>!/^[a-zA-Z0-9-_]+$/.test(e))))return void ie({dimensionElement:this.domainInput,text:ee.pleaseEnterValidDomain});if(!i){const e=t.split(".").pop();if(!window.domainZoneList.includes(e))return void ie({dimensionElement:this.domainInput,text:ee.pleaseEnterValidDomain})}}if(!this.selectedDomain){if(this.filters.map((({value:e})=>e)).includes(t))return void ie({dimensionElement:this.domainInput,text:ee.thisDomainAlreadyInList})}if(this.selectedDomain){{const i=this.filters.filter((({value:e})=>e!==this.selectedDomain));i.push({country:this.country,deleted:!1,value:t,view:e}),i.sort(te),this.filters=i}(0,n.Z)({type:"change site filter",country:this.country,domain:t,selectedDomain:this.selectedDomain})}else{if(this.filters.some((({deleted:e,disabled:t})=>!e&&!t))&&!E.Z.getStateSync().user.premium)return void this.showPremiumPopup();(0,n.Z)({type:"сounters.increase",property:"popup: smart settings: add rule"});const i=this.country?{country:this.country,domain:t,type:"proxy"}:{domain:t,type:"direct"},o=this.filters.slice();o.unshift({country:this.country,deleted:!1,value:t,view:e}),this.filters=o,f.Z.siteFilters.add(i)}this.resetSelection()}else ie({dimensionElement:this.domainInput,text:ee.pleaseEnterValidDomain})}async showPremiumPopup(){if(this.popupPremiumFreeze)return;this.popupPremiumFreeze=!0;const e=document.createElement("popup-premium-onerule");e.style.cssText="top:-100%;",document.body.append(e),p.Z.partial({category:"premium",action:"show"});const t=await m;if("number"==typeof t&&t<=62){const t=-100,i=0;await g({duration:800,action:o=>{const n=o*(i-t)+t;e.style.cssText=`top:${n}%;`}})}else{const t=e.animate([{top:"-100%"},{top:"0"}],{duration:800,easing:"linear"});await new Promise((e=>{t.onfinish=e}))}e.style.cssText="",this.popupPremiumFreeze=!1}}customElements.define("index-filters",oe);const ne=async({experiments:e,promotions:t,showSpeedPromo:i,user:o})=>{if("logined"===o.type&&o.premium){const e=o.loginData.subscription.paidUntil,t=e?new Date(e):void 0,i=await u.Z.get("userClosedWarnToPremiumEndDate");if(!(!t||o.loginData.subscription.auto_renewal||i===String(t)||Date.now()<t.getTime()-1728e5))return{type:"premium expiration"}}const n=o.premium,s=Date.now(),r=(()=>{const e=t.filter((({banner:e,from:t,till:i})=>e&&t<=s&&s<=i)).filter((({kind:e})=>"personal"===e||!n)).sort((({kind:e},{kind:t})=>e===t?0:"personal"===e?-1:1));if(!e.length)return;const{id:i,banner:o}=e[0];return{id:i,banner:o}})();if(r)return{banner:r.banner,promotionId:r.id,type:"custom"};return await(async()=>{if(!i)return!1;if(n)return!1;const t=e[c().experiments.fastServersWarning.id];if(!["1","2","3"].includes(t))return!0;const{installDate:o}=await u.Z.get("statistics");return"number"!=typeof o||(Date.now()-o)/864e5>7})()?{type:"speed"}:void 0},{_:se}=self,re=new class{constructor(){this._activeBanner=void 0,this._listeners=[],(async()=>{const e=await E.Z.getStateAsync(),t="proxy"===e.pac.mode;this._showSpeedPromo=t;const i=this._activeBanner,o=await ne(Object.assign({showSpeedPromo:t},e));if(!se.isEqual(i,o)){this._activeBanner=o;for(const e of this._listeners)e(o,i)}})(),E.Z.onChange((({promotions:e,user:t})=>({user:Boolean(t.email),promotions:e})),(()=>{this.refresh()}))}addListener(e){this._listeners.push(e)}get(){return this._activeBanner}async refresh(){const e=await E.Z.getStateAsync(),t=this._activeBanner,i=await ne(Object.assign({showSpeedPromo:this._showSpeedPromo},e));if(!se.isEqual(t,i)){this._activeBanner=i;for(const e of this._listeners)e(i,t)}}removeListener(e){this._listeners=this._listeners.filter((t=>t!==e))}};var ae=i(2261);const le="undefined"!=typeof browser?browser:chrome,ce=new class{constructor(){this._state=[],this._callbacks=[],le.runtime.connect({name:"permissions"}).onMessage.addListener((e=>{this._state=e,this._callbacks.forEach((t=>{t(e)}))})),(async()=>{this._state=await(0,n.Z)({type:"permissions.get"})})()}addListener(e){this._callbacks.push(e)}get(){return this._state}includes(e){return this._state.includes(e)}},de=y({change:"change",connectionsNotEncrypted:"your_browsers_connections_are_not_encrypted",privacyProtected:"your_privacy_is_protected",protectionDisabled:"privacy_protection_disabled",startVpn:"start_vpn"});function pe(){const{switchesView:e}=this;return o.dy`
  <style>
  ${d}
  :host > .In{
    width: 100%;
    height: 100%;
    white-space: nowrap;
    position: relative;
  }
  :host > .In.transition{
    transition: margin-left 0.25s;
  }
  :host > .In > .In{
    display: flex;
    width: 200%;
    height: 100%;
    align-items: center;
  }
  :host(.proxyEnabled) > .In{
    margin-left: -100%;
  }
  :host(.withPromo) > .In{
    height: auto;
  }

  :host index-home-switches{
    padding: 12px 22px 0;
    text-align: left;
  }
  :host index-home-promo{
    display: none;
  }
  :host(.withPromo) index-home-promo{
    display: block;
    border-bottom: 4px solid transparent;
  }

  .Inactive,
  .Active{
    flex: 1;
  }
  :host(.withPromo) .Inactive,
  :host(.withPromo) .Active{
    align-items: stretch;
  }

  .Inactive{
    text-align: center;
    white-space: normal;
  }
  :host(.withPromo) .Inactive{
    vertical-align: top;
  }
  .Inactive::before{
    content: '';
    display:block;
    background: url( '/images/global_protection_disabled.svg' ) 50% 0 no-repeat;
    background-size: auto 100%;
    width: 100%;
    overflow:hidden;font-size:0;text-indent:-9999px;height:0;
    padding-top:114px;
  }
  :host(.withPromo) .Inactive::before{
    padding-top: 76px;
  }

  /** Active proxy */
  :host(.withPromo) .Active{
    padding-top: 9px;
  }
  .Active::before{
    content:' ';
    display:block;
    background: url( '/images/global_protection_enabled.svg' ) 50% 0 no-repeat;
    background-size: auto 100%;
    overflow:hidden;font-size:0;text-indent:-9999px;height:0;
    padding-top:112px;
  }
  :host(.withPromo) .Active::before{
    padding-top: 91px;
  }

  .Inactive_Text{
    font-size: 14px;
    padding: 4px 28px 0;
    line-height: 17px;
  }
  .Inactive_Title{
    font-size: 18px;
    font-weight: 600;
    padding-top: 10px;
    color: #994136;
  }
  :host(.withPromo) .Inactive_Title{
    padding-top: 0;
  }
  .Inactive_ButtonOut{
    padding-top: 24px;
  }
  :host(.withPromo) .Inactive_ButtonOut{
    padding-top: 10px;
  }
  .Inactive_Button{
    display:inline-block;
    vertical-align:top;
    cursor: pointer;
    text-decoration: none;
    color: #fff;
    min-width: 208px;
    height: 45px;
    line-height: 42px;
    border-radius: 4px;
    background: #3d973f;
    font-size: 17px;
    text-align: center;
    padding: 0 10px;
  }


  .Active_Text{
    font-size:18px;
    line-height: 1;
    padding: 27px 28px 0;
    color:#3b9946;
    text-align: center;
  }
  :host(.withPromo) .Active_Text{
    padding-top: 7px;
  }

  .Active_Country_Out{
    padding: 28px 20px 0;
  }
  :host(.withPromo) .Active_Country_Out{
    padding-top: 20px;
  }

  .Active_Country{
    cursor: pointer;
    border: 1px solid #bcbcbc;
    border-radius: 4px;
    text-align: justify;
    height: 58px;
    padding: 0 20px;
    cursor:pointer;
  }
  .Active_Country:hover{
    background: #efefef;
  }
  .Active_Country > .In{
    display: table;
    height: 100%;
    width: 100%;
  }
  .Active_Country > .In > .E{
    display: table-cell;
    vertical-align: middle;
  }
  .Active_Country > .In > .E:first-child{
    width: 1px;
    padding-right: 12px;
  }
  .Active_Country > .In > .E:last-child{
    width: 1px;
  }
  .Active_Country img{
    display: block;
    border-radius: 4px;
    filter: saturate(135%);
    opacity:0.7;
    border: 1px solid rgba(0, 0, 0, 0.22);
  }
  .Active_Country_Name{
    font-size: 18px;
  }

  .ChangeButton{
    display:inline-block;
    vertical-align:top;
    font-size: 12px;
    border-radius: 4px;
    line-height: 18px;
    text-align: center;
    background: #fff;
    border: 1px solid #268328;
    color: #268328;
    padding: 0 8px;
  }

  .Rating{
    background: url( '/images/pings/1.svg' ) 0 0 no-repeat;
    background-size: 100% 100%;
    width: 23px;
    overflow:hidden;font-size:0;text-indent:-9999px;height:0;
    padding-top:12px;
    margin-left: auto;
    border-right: 15px solid transparent;
  }
  .Rating.r2{
    background-image: url( '/images/pings/2.svg' );
  }
  .Rating.r3{
    background-image: url( '/images/pings/3.svg' );
  }
  .Rating.r4{
    background-image: url( '/images/pings/4.svg' );
  }
  .Rating.r5{
    background-image: url( '/images/pings/5.svg' );
  }

  .SettingsIcon{
    position: absolute;
    top: 20px;
    right: 20px;
    width: 40px;
  }
  :host(.withPromo) .SettingsIcon{
    top: calc(88px + 12px);
  }
  .SettingsIcon > .In{
    position: relative;
    border: 1px solid #bcbcbc;
    width: 38px;
    overflow:hidden;font-size:0;text-indent:-9999px;height:0;
    padding-top:38px;
    border-radius: 4px;
  }
  .SettingsIcon > .In::after{
    content: '';
    display: block;
    background: url( '/images/settings_grey.svg' ) 0 0 no-repeat;
    background-size: 100% 100%;
    position: absolute;
    width: 17px;
    overflow:hidden;text-indent:-9999px;height:0;
    padding-top: 17px;
    top: calc(50% - 17px / 2);
    left: calc(50% - 17px / 2);
  }
  .SettingsIcon_GreenCircle{
    width: 16px;
    overflow:hidden;font-size:0;text-indent:-9999px;height:0;
    padding-top:16px;
    background: #3b9946;
    border: 4px solid #fff;
    border-radius: 50%;
    position: absolute;
    left: -11px;
    bottom: -11px;
  }
  .SettingsIcon_ClickArea{
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    overflow: hidden;
    text-indent: -9999px;
    cursor: pointer;
  }
  </style>

  <index-home-promo .activeBanner="${this.activeBanner}"></index-home-promo>
  <div class="In ${"simple"!==e.type?"":"transition"}">
    <div class="In"><!--
   --><div class="Inactive">
        <div class="Inactive_Title">${de.protectionDisabled}</div>
        <div class="Inactive_Text">${de.connectionsNotEncrypted}</div>
  ${(()=>"simple"===e.type?o.dy`
        <div class="Inactive_ButtonOut"><!--
       --><div class="Inactive_Button" @click="${this.enableProxy}">
            ${de.startVpn}
          </div><!--
     --></div>`:o.dy`
        <index-home-switches
          .proxyEnabled="${this.proxyEnabled}"
          .proxyCountry="${this.country}"
          .view="${e}"
          @proxyswitch="${this.proxySwitch}"
          @domainproxyswitch="${this.domainProxySwitch}"
          @countrychange="${this.countryChange}"
          @domaincountrychange="${this.domainCountryChange}">
        </index-home-switches>`)()}
      </div><!--
   --><div class="Active">
        <div class="Active_Text">${de.privacyProtected}</div>
  ${(()=>"simple"!==e.type?o.dy`
          <index-home-switches
            .proxyEnabled="${this.proxyEnabled}"
            .proxyCountry="${this.country}"
            .view="${e}"
            @proxyswitch="${this.proxySwitch}"
            @domainproxyswitch="${this.domainProxySwitch}"
            @countrychange="${this.countryChange}"
            @domaincountrychange="${this.domainCountryChange}">
          </index-home-switches>`:o.dy`
          <div class="Active_Country_Out">
            <div class="Active_Country" @click="${this.openLocations}"><div class="In">
    ${(()=>{return this.country?o.dy`
              <div class="E"><!--
             --><img src="${e=this.country,"usw"===e&&(e="us"),"uk"===e&&(e="gb"),e?`/images/flags/${e}.svg`:"/images/empty.png"}" width="30" height="20" /><!--
           --></div>`:"";var e})()}
              <div class="E">
                <div class="Active_Country_Name">${this.countryName}</div>
              </div>
    ${e.rating?o.dy`
              <div class="E">
                <div class="Rating r${e.rating}"></div>
              </div>`:""}
              <div class="E"><div class="ChangeButton">${de.change}</div></div>
            </div></div>
          </div>`)()}
      </div><!--
  --></div>
  </div>

  <div class="SettingsIcon">
    <div class="In"></div>
  ${(()=>this.settingsIconNewFeature?o.dy`
    <div class="SettingsIcon_GreenCircle"></div>`:"")()}
    <div class="SettingsIcon_ClickArea" @click="${this.openSettings}"></div>
  </div>`}var ue=i(930),he=i(3294);const ge=Object.freeze(["autocomplete","colspan","height","href","name","rowspan","src","target","type","width"]);const me=(e,t=(e=>e))=>{let i=(e=>Object.assign({},e,{type:"string"==typeof e.tag?"element":"node"}))(e);if("node"===i.type){if("string"!=typeof i.text)throw new Error("createElement called without text property");return document.createTextNode(i.text)}const{attributes:o,tag:n}=i;let s=document.createElement(n);if(i.class){let e=t(i.class);s.setAttribute("class",e)}if(i.style&&s.setAttribute("style",i.style),o)for(const[e,t]of Object.entries(o)){!ge.includes(e)&&!e.startsWith("data-")||("src"===e&&"img"!==n||s.setAttribute(e,t))}if(i.node&&i.node(s),i.text&&(s.textContent=i.text),i.children){i.children.map((e=>me(e,t))).forEach((e=>{s.appendChild(e)}))}return s},fe=me;class xe extends HTMLElement{constructor(){super(),this.hasRenderedDom=!1;const e=this.attachShadow({mode:"open"}),t=ue.dy`
    <style>
    ${d}
    :host{
      display:block;
      height: 82px;
      overflow: hidden;
      margin: 4px 4px 0;
      position: relative;
    }
    a{
      display: block;
      position: absolute;
      top:0px;
      right:0px;
      bottom:0px;
      left:0px;
      overflow: hidden;
      text-indent: -9999px;
      z-index: 3;
    }
    </style>`;(0,he.sY)(t,e,{scopeName:this.tagName.toLowerCase()})}renderDomFromJson({jsonStructure:e,link:t,promotionId:i}){const o=this.shadowRoot;if(this.hasRenderedDom)for(const e of o.children)"style"!==e.tagName.toLowerCase()&&e.remove();this.hasRenderedDom=!0;const n=fe(e),s=document.createElement("a");s.href=t,s.target="_blank",i&&s.addEventListener("click",(()=>{p.Z.partial({category:"banner",action:"click",label:"banner_promo_"+i})})),o.appendChild(n),o.appendChild(s)}}customElements.define("downloadable-promo",xe);const ve=y({continueUsing:"continue_using_premium",goAheadAndRenewIt:"go_ahead_and_renew_it",premiumIsAboutToExpire:"your_premium_is_about_to_expire"});class be extends o.oi{render(){return o.dy`
    <style>
    ${d}
    :host{
      display: block;
      margin: 1px 0 0;
      background: #fcd0cb;
      border-bottom: 1px #994136 solid;
      padding: 10px 10px 10px;
    }
    .Close{
      position: absolute;
      top: -5px;
      right: -1px;
      color: #994136;
      cursor: pointer;
      width: 10px;
      padding-top: 10px;
      border: 11px solid transparent;
      height: 0;
      overflow: hidden;
      background: url( '/images/popup_close_2.svg#pink' ) 0 0 no-repeat;
      background-size: 100% 100%;
    }
    .Close:hover{
      background-image: url( '/images/popup_close_2.svg#white' );
    }
    .Close::after{
      content: '';
      display: block;
      position: absolute;
      width: 1px;
      height: 1px;
      top: 0;
      left: 0;
      background: url( '/images/popup_close_2.svg#white' ) 0 -5000px no-repeat;
    }
  
    .Title{
      color: #994136;
      font-size: 14px;
      text-align: center;
    }
    .Description{
      color: #1c304e;
      font-size: 12px;
      text-align: center;
    }
  
    .Link_Out{
      text-align: center;
      font-size: 12px;
      padding-top: 5px;
    }
    .Link{
      display:inline-block;
      vertical-align:top;
      cursor:pointer;
    }
    .Link:link,
    .Link:visited{
      text-decoration: none;
      border-bottom:1px #1c304e solid;
      color: #1c304e;
    }
    .Link:hover{
      color: #fff;
      border-bottom:1px solid #fff;
    }
    </style>
    
    <div class="Close" @click="${this.expirationClose}"></div>
    <div class="Title">${ve.premiumIsAboutToExpire}</div>
    <div class="Description">${ve.goAheadAndRenewIt}</div>
    <div class="Link_Out"><!--
   --><a class="Link" href="${this.expirationPremiumLink}" target="_blank">
        ${ve.continueUsing}
      </a><!--
 --></div>`}get expirationPremiumLink(){return F({action:e=>Object.assign(e,{utm_source:"chromium extension",utm_campaign:"default_campaign"}),storeState:E.Z.getStateSync(),url:R.Z.base+"/en/orders/new?plan_id=annual"})}expirationClose(){this.dispatchEvent(new CustomEvent("expirationclose"))}}customElements.define("premium-expiration-soon",be);const ye=({prices:e,priceTrial:t})=>{let i=e.slice().sort(((e,t)=>e.value/e.duration-t.value/t.duration))[0],o=e.slice().sort(((e,t)=>t.value/t.duration-e.value/e.duration))[0],{currency:n,oldValue:s}=o;"USD"===n&&(n="$");let r=Math.floor(100*i.value/i.duration)/100,a=s?Math.floor(100*s/o.duration)/100:0,l=t||0;return{currency:n,duration:i.duration,oldPrice:a,price:r,trialDays:l}},we=y({getTurboSpeed:"get_turbo_speed",moneyBackGuarantee:"7_days_money_back_guarantee",upgradeConnectionSpeed:"upgrade_connection_speed"});class ke extends((0,C.$)(E.Z)(o.oi)){render(){const e=(0,v.Z)("from_only_X_per_month").replace(/XXX/g,String(this.price));return o.dy`
    <style>
    ${d}
    :host{
      display: block;
      position: relative;
      background: #c0392b;
      margin: 6px 6px 0 6px;
      border-radius: 4px;
      height: 82px;
      color: #fff;
      text-align: center;
      line-height: 1;
    }
    :host > .In{
      display: table;
      height: 100%;
      width: 100%;
    }
    :host > .In > .In{
      display: table-cell;
      vertical-align: middle;
      padding: 0 7px;
    }
    .Title{
      text-transform: uppercase;
      font-size: 23px;
      font-weight: bold;
    }
    .Price{
      color: #f1c40f;
      font-size: 18px;
      font-weight: bold;
      padding: 3px 0 7px;
    }
    .Days{
      color: #e1afab;
      font-size: 12px;
    }
    .Link{
      display: block;
      position: absolute;
      top:0px;
      right:0px;
      bottom:0px;
      left:0px;
      white-space: nowrap;
      overflow: hidden;
      text-indent: -9999px;
      font-size: 0;
    }
    </style>
    
    <div class="In"><div class="In">
      <div class="Title">${we.upgradeConnectionSpeed}</div>
      <div class="Price">${e}</div>
      <div class="Days">${we.moneyBackGuarantee}</div>
    </div></div>
    <a class="Link" @click=${this.linkClick} href="${this.premiumLink}" target="_blank">
      ${we.getTurboSpeed}
    </a>`}static get properties(){return{price:{type:Number}}}get premiumLink(){return F({action:e=>Object.assign(e,{utm_source:"chromium extension",utm_medium:"banner",utm_campaign:"default_campaign"}),storeState:E.Z.getStateSync(),url:R.Z.premium})}stateChanged({prices:e,priceTrial:t}){this.price=ye({prices:e,priceTrial:t}).price}async linkClick(){var e,t;p.Z.partial({category:"banner",action:"click",label:"banner_speed_new"}),await new Promise((e=>{setTimeout(e,50)})),null===(e=self)||void 0===e||null===(t=e.close)||void 0===t||t.call(e)}}customElements.define("upgrade-speed-banner",ke);const{_:_e}=self;class Ee extends HTMLElement{constructor(){super(),this._activeBanner=null,this.expirationClose=this.expirationClose.bind(this);const e=this.attachShadow({mode:"open"}),t=ue.dy`
    <style>
    ${d}
    :host{
      display: block;
      height:82px;
    }
    </style>`;(0,he.sY)(t,e,{scopeName:this.tagName.toLowerCase()})}get activeBanner(){return this._activeBanner}set activeBanner(e){_e.isEqual(this._activeBanner,e)||(this._activeBanner=e,this.renderActivePromo(this.activeBanner))}async expirationClose(){var e,t;const{user:i}=await E.Z.getStateAsync(),o=null===(e=i.loginData)||void 0===e||null===(t=e.subscription)||void 0===t?void 0:t.paidUntil;if(!o)return;let n=new Date(o);await u.Z.set("userClosedWarnToPremiumEndDate",String(n)),re.refresh()}async renderActivePromo(e){const t=this.shadowRoot;for(const e of t.children)"style"!==e.tagName.toLowerCase()&&e.remove();const i=(()=>{if(e){if("premium expiration"===e.type){const e=document.createElement("premium-expiration-soon");return e.addEventListener("expirationclose",this.expirationClose),e}if("custom"===e.type){const t=document.createElement("downloadable-promo"),{promotionId:i,banner:{link:o,structure:n}}=e;return t.renderDomFromJson({link:o,jsonStructure:n,promotionId:i}),t}return"speed"===e.type?document.createElement("upgrade-speed-banner"):void 0}})();i&&t.appendChild(i),"custom"===(null==e?void 0:e.type)&&p.Z.partial({category:"banner",action:"show",label:"banner_promo_"+e.promotionId}),"speed"===(null==e?void 0:e.type)&&p.Z.partial({category:"banner",action:"show",label:"banner_speed_new"})}}customElements.define("index-home-promo",Ee);const Ce=y({otherWebsites:"other_websites"}),$e=e=>("usw"===e&&(e="us"),"uk"===e&&(e="gb"),e?`/images/flags/${e}.svg`:"/images/empty.png");class Se extends o.oi{render(){return o.dy`
    <style>
    ${d}
    :host{
      display: block;
    }
    .Row::after{
      content:' ';clear:both;display:block;width:0;height:0;overflow:hidden;font-size:0;
    }
    .Row + .Row{
      padding-top: 8px;
    }

    .Switch,
    .Flag_Out{
      float: right;
      width: 61px;
      padding-left: 11px;
      min-height: 1px;
    }

    .Name{
      white-space: nowrap;
      overflow: hidden;
      line-height: 26px;
      text-overflow: ellipsis;
    }

    .Flag{
      border: 1px solid #bcbcbc;
      border-radius: 3px;
      padding: 2px 27px 2px 2px;
      cursor: pointer;
      position: relative;
    }
    .Flag:hover{
      border-color: #888;
    }
    .Flag::after{
      content: '';
      display: block;
      background: url( '/images/flag_arrow_right.svg' ) 0 0 no-repeat;
      background-size: 100% 100%;
      width: 5px;
      overflow:hidden;font-size:0;text-indent:-9999px;height:0;
      padding-top:9px;
      position: absolute;
      right: 10px;
      top: 50%;
      margin-top: -4px;
    }
    .Flag img{
      display: block;
      border-radius: 4px;
      filter: saturate(135%);
      opacity:0.7;
      border: 1px solid rgba(0, 0, 0, 0.22);
    }
    </style>

    <div class="Row">
      <div class="Switch">
        <c-switch .on="${"complex on"===this.view.type}" @click="${this.domainProxySwitch}"></c-switch>
      </div>
      <div class="Flag_Out">
  ${(()=>{if(!("country"in this.view))return"";const e=this.view.country;return o.dy`
        <div class="Flag" @click="${this.domainCountryChange}">
          <img src="${$e(e)}" width="30" height="20" alt="${e}"/>
        </div>`})()}
      </div>
      <div class="Name">${this.view.view}</div>
    </div>

    <div class="Row">
      <div class="Switch">
        <c-switch .on="${this.proxyEnabled}" @click="${this.proxySwitch}"></c-switch>
      </div>
      <div class="Flag_Out">
  ${(()=>this.proxyEnabled?o.dy`
        <div class="Flag" @click="${this.countryChange}">
          <img src="${$e(this.proxyCountry)}" width="30" height="20" alt="${this.proxyCountry}"/>
        </div>`:"")()}
      </div>
      <div class="Name">${Ce.otherWebsites}</div>
    </div>`}static get properties(){return{proxyEnabled:{type:Boolean},proxyCountry:{type:String},view:{type:Object}}}constructor(){super(),this.view={}}proxySwitch(){this.dispatchEvent(new CustomEvent("proxyswitch"))}domainProxySwitch(){this.dispatchEvent(new CustomEvent("domainproxyswitch"))}countryChange(){this.dispatchEvent(new CustomEvent("countrychange"))}domainCountryChange(){this.dispatchEvent(new CustomEvent("domaincountrychange"))}}customElements.define("index-home-switches",Se);const Be=c().proxy.defaultCountry||"nl",Le=async()=>{let e=await u.Z.get("newSettingsFeatureTimezoneChange1");return!("boolean"==typeof e&&!e)||Boolean(E.Z.getStateSync().webrtcBlock&&!ce.includes("privacy"))};class Pe extends((0,C.$)(E.Z)(o.oi)){render(){return pe.call(this)}static get properties(){return{activeBanner:{type:Object},countries:{type:Array},country:{type:String},countryName:{type:String},proxyEnabled:{type:Boolean},settingsIconNewFeature:{type:Boolean},switchesView:{type:Object}}}constructor(){super(),this.activeBanner=re.get(),this.switchesView={type:"simple",rating:void 0},this.countries=[],this.proxyEnabled=!1,this.settingsIconNewFeature=!1,this.activeBannerListener=this.activeBannerListener.bind(this)}async connectedCallback(){super.connectedCallback(),re.addListener(this.activeBannerListener),this.settingsIconNewFeature=await Le()}disconnectedCallback(){re.removeListener(this.activeBannerListener)}firstUpdated(e){var t,i;if(super.firstUpdated(e),(async()=>{this.settingsIconNewFeature=await Le()})(),!(null===(t=this.shadowRoot)||void 0===t||null===(i=t.querySelector)||void 0===i?void 0:i.call(t,"index-home-promo")))throw new Error("index-home: index-home-promo element does not exist");this.classList.toggle("proxyEnabled",this.proxyEnabled),this.classList.toggle("withPromo",Boolean(this.activeBanner))}updated(e){e.has("activeBanner")&&this.classList.toggle("withPromo",Boolean(this.activeBanner)),e.has("proxyEnabled")&&this.classList.toggle("proxyEnabled",this.proxyEnabled)}stateChanged({domain:e,proxyServers:t,pac:i,ping:o,user:n}){const s=Array.from(n.premium?t.premiumCountries():t.freeCountries());this.countries=s,this.country=i.country,this.proxyEnabled="proxy"===i.mode,(()=>{const{country:t,filters:r}=i,{premium:a}=n,l=(()=>{var e;if(o.length&&t)return null===(e=o.find((({country:e,premium:i})=>e===t&&i===a)))||void 0===e?void 0:e.mark})();if(!e)return void(this.switchesView={type:"simple",rating:l});const c=(0,ae.Z)(r,e);if(c){const{country:e,proxyMode:t}=c,i=c.value instanceof RegExp?c.value.toString():c.value,o=x.ZP.toUnicode(i);if(!t)return void(this.switchesView={domain:i,type:"complex off",view:o});this.switchesView={country:s.includes(e)?e:Be,domain:i,type:"complex on",view:o}}else this.switchesView={type:"simple",rating:l}})()}get countryName(){return this.country?(0,v.Z)("country_name_"+this.country.toUpperCase()):""}activeBannerListener(e){console.warn("activeBannerListener",e),this.activeBanner=e||null}countryChange(){E.Z.dispatch({type:"Page: set",page:"index:locations"})}domainProxySwitch(){let{domain:e}=this.switchesView;f.Z.siteFilters.toggle(e)}domainCountryChange(){let{domain:e}=this.switchesView;E.Z.dispatch({type:"Page: set",page:"index:locations:"+e})}enableProxy(){f.Z.enable()}openLocations(){E.Z.dispatch({type:"Page: set",page:"index:locations"})}async openSettings(){await u.Z.set("newSettingsFeatureTimezoneChange1",!1),E.Z.dispatch({type:"Page: set",page:"index:settings"})}proxySwitch(){this.proxyEnabled?f.Z.disable():f.Z.enable()}}customElements.define("index-home",Pe);const Ie=(e,t,i)=>e.premium&&!t?"premium":e.code===i?"current":"change";function Te(e){let{key:t}=e;if("ArrowDown"!==t&&"ArrowUp"!==t)if("Enter"!==t)this.charsBuffer.keydownListener(e);else{if(!this.highlightedCountry)return;let{code:e}=this.highlightedCountry,t=Ie(this.highlightedCountry,this.premiumUser,this.country);if("current"===t)return;this.countryClick({detail:{mode:t,country:e}})}else{e.preventDefault();let i=(()=>{let e=this.namesList.length;const i=this.highlightedCountry;if(!i)return"ArrowUp"===t?e-1:0;let o=this.namesList.findIndex((({code:e,premium:t})=>i.code===e&&i.premium===t));return o+="ArrowDown"===t?1:-1,(o+e)%e})(),o=this.namesList[i];this.highlightedCountry={code:o.code,premium:o.premium};let n=this.scrollElement.scrollTop,s=this.scrollElement.offsetHeight,r=n+s,a=o.element.offsetHeight,l=o.element.offsetTop,c=l+a;if(l>=n&&c<=r)return;let d=l>=n?c-s+4:l-2;this.scrollElement.scrollTop=d}}var Ze=i(9174);const ze=y({virtualLocations:"virtual_locations",serversInVirtualLocations:"N_servers_in_N_virtual_Locations"});function De(){const e=ze.serversInVirtualLocations.replace(/AAA/g,"600+").replace(/BBB/g,String(this.countries.filter((({premium:e})=>e)).length));return o.dy`
  <style>
  ${d}
  :host > .In{
    overflow: auto;
    height: 100%;
  }

  .Head{
    padding: 11px 12px;
    text-align: center;
    position: relative;
  }
  .Head > .T{
    display:inline-block;
    vertical-align:top;
    position: relative;
  }
  .Head_Title{
    font-size: 20px;
    font-weight: 600;
    line-height: 1.2;
  }
  .ServerCount{
    font-size: 12px;
    line-height: 1.25;
    padding-top: 2px;
  }

  .Back{
    position: absolute;
    left: 12px;
    top: 16px;
    font-size: 14px;
    line-height: 1.2;
    padding: 0 0 0 18px;
    cursor: pointer;
  }
  .Back::before{
    content: '';
    display: block;
    background: url('/images/arrow_left.svg') 0 0 no-repeat;
    background-size: 100% 100%;
    width: 9px;
    overflow:hidden;font-size:0;text-indent:-9999px;height:0;
    padding-top: 16px;
    position: absolute;
    left: 0;
    top: calc(50% - 8px);
  }

  .Helper{
    position: absolute;
    left: calc(100% + 5px);
    top: calc(50% - 8px);
    background: url( '/images/information_grey.svg' ) 0 0 no-repeat;
    background-size: 100% 100%;
    width: 16px;
    overflow:hidden;font-size:0;text-indent:-9999px;height:0;
    padding-top: 16px;
    cursor: pointer;
    text-align: left;
  }
  .Helper:hover{
    background-image: url( '/images/information_green.svg' );
  }
  .Helper::after{
    content: '';
    display: block;
    background: url( '/images/information_green.svg' ) 0 -5000px no-repeat;
    width: 1px;
    height: 1px;
    overflow: hidden;
    position: absolute;
    left: 0;
    top: 0;
  }

  .Sections{
    padding: 0px 12px 12px;
  }
  </style>

  <div class="In">
    <div class="Head"><!--
   --><div class="Back" @click="${this.back}">Back</div><!--
   --><div class="T">
        <div class="Head_Title">${ze.virtualLocations}</div>
        <div class="Helper" @click="${this.openHelp}">?</div>
      </div><!--
   --><div class="ServerCount">${e}</div><!--
 --></div>
    <div class="Sections">
  ${this.countries.map((e=>o.dy`<index-locations-element
      @countryclick="${this.countryClick}"
      @favorite="${this.favorite}"
      @mousemove="${this.elementHighlight(e)}"
      .data="${e}"
      .highlighted="${((e,t)=>Boolean(t&&t.code===e.code&&t.premium===e.premium))(e,this.highlightedCountry)}"
      .mode="${Ie(e,this.premiumUser,this.country)}"
    ></index-locations-element>`))}
    </div>
  </div>`}function Oe(){return o.dy`
  <style>
  ${d}
  :host{
    display: block;
    padding: 0 7px 0 10px;
    cursor: pointer;
    border: 1px solid transparent;
    border-radius: 4px;
  }
  :host(.highlight){
    background: #f7f8fc;
  }
  :host(.current){
    cursor: default;
  }
  :host(.current),
  :host(.current.highlight){
    background: #f0f5f0;
  }
  
  :host > .In{
    display: flex;
    align-items: center;
    height: 40px;
    background: url( '/images/favorites/hovered.svg' ) 0 -5000px no-repeat;
  }
  :host > .In > .E:first-child{
    width: 32px;
    padding: 0 10px 0 0;
    flex-shrink: 0;
    flex-grow: 0;
  }
  :host > .In > .E.country{
    padding-right: 5px;
    flex-grow: 1;
  }
  :host > .In > .E.mark{
    width: 23px;
    padding-left: 10px;
    flex-shrink: 0;
    flex-grow: 0;
  }
  :host > .In > .E.favorite{
    width: 19px;
    padding-left: 10px;
    flex-shrink: 0;
    flex-grow: 0;
  }

  .Flag{
    display: block;
    border-radius: 4px;
    filter: saturate(135%);
    opacity:0.7;
    border: 1px solid rgba(0, 0, 0, 0.22);
  }
  .Country{
    font-size: 13px;
    line-height: 1.2;
    color: #333;
  }

  .Favorite{
    background: url( '/images/favorites/static.svg' ) 0 0 no-repeat;
    background-size: 100% 100%;
    width: 13px;
    overflow:hidden;font-size:0;text-indent:-9999px;height:0;
    padding-top: 12px;
    cursor: pointer;
    border: 3px solid transparent;
  }
  .Favorite:hover{
    background-image: url( '/images/favorites/hovered.svg' );
  }
  .Favorite.favorited,
  .Favorite.favorited:hover{
    background-image: url( '/images/favorites/starred.svg' );
  }

  .Mark{
    display:inline-block;
    vertical-align: middle;
    width: 23px;
    overflow:hidden;
    font-size:0;text-indent:-9999px;height:0;
    padding-top: 12px;
    background: url( '/images/pings/1.svg' ) 0 0 no-repeat;
    background-size: 100% 100%;
  }
  .Mark.mark2{
    background-image: url( '/images/pings/2.svg' );
  }
  .Mark.mark3{
    background-image: url( '/images/pings/3.svg' );
  }
  .Mark.mark4{
    background-image: url( '/images/pings/4.svg' );
  }
  .Mark.mark5{
    background-image: url( '/images/pings/5.svg' );
  }
  </style>

  <div class="In" @click="${this.fullElementClick}">
    <div class="E">
      <img class="Flag" src="${e=this.data.code,"usw"===e&&(e="us"),"uk"===e&&(e="gb"),e?`/images/flags/${e}.svg`:"/images/empty.png"}" width="30" height="20"/>
    </div>
    <div class="E country">
      <div class="Country">${this.data.name}</div>
    </div>
  ${(()=>this.data.delay?o.dy`
    <div class="E mark"><!--
   --><div class="Mark mark${this.data.mark}">${this.data.mark}</div><!--
 --></div>`:"")()}
  ${(()=>"boolean"!=typeof this.data.favorited?"":o.dy`
    <div class="E favorite">
      <div
        class="Favorite${this.data.favorited?" favorited":""}"
        @click="${this.favoritesClick}"></div>
    </div>`)()}
  </div>`;var e}class Ae extends o.oi{render(){return Oe.call(this)}static get properties(){return{data:{type:Object},highlighted:{type:Boolean},mode:{type:String}}}constructor(){super(),this.data={},this.highlighted=!1,this.mode=""}updated(e){if(e.has("highlighted")){let t=this.highlighted;t!==e.get("highlighted")&&this.classList.toggle("highlight",t)}e.has("mode")&&(this.classList.toggle("current","current"===this.mode),this.classList.toggle("premium","premium"===this.mode))}favoritesClick(){this.dispatchEvent(new CustomEvent("favorite",{detail:{country:this.data.code,favorited:!this.data.favorited}}))}fullElementClick(e){const t=e.target instanceof HTMLElement&&e.target.classList.contains("Favorite");"current"===this.mode||t||this.dispatchEvent(new CustomEvent("countryclick",{detail:{mode:this.mode,country:this.data.code}}))}}customElements.define("index-locations-element",Ae);const{_:Ne}=self,Fe="undefined"!=typeof browser?browser:chrome,Re=e=>{var t;let i=(0,v.Z)("country_name_"+e.toUpperCase());if(i)return i;let o=Fe.i18n.getUILanguage(),n=(null===(t=Fe.runtime.getManifest())||void 0===t?void 0:t.version)||"n/a",s="failed to look up country name for: "+e+" with locale: "+o+" at popup.js";return Ze.Z.warn(s),p.Z.partial({category:"error",action:n,label:s,value:"0",noninteraction:!1}),e.toUpperCase()||"N/A"};class Me extends((0,C.$)(E.Z)(o.oi)){render(){return De.call(this)}static get properties(){return{countries:{type:Array},country:{type:String},domain:{type:String},highlightedCountry:{type:Object},premiumUser:{type:Boolean},proxyCountry:{type:String},proxyList:{type:Array}}}stateChanged(e){const{pac:t,user:i}=e;this.countries=((e,t)=>{const{favorites:i,ping:o,proxyServers:n,user:s}=e,r=s.premium,a=[];for(const[e,s]of n){const n=t(e);if(!r){const t=s.free;if(Array.isArray(t)&&t.length){const t={id:e,code:e,name:n,premium:!1},i=o.find((({country:t,premium:i})=>t===e&&!i));if(i){const{delay:e,mark:o}=i;Object.assign(t,{delay:e,mark:o})}a.push(t)}}{const t=s.premium;if(Array.isArray(t)&&t.length){const t={id:e+"_premium",code:e,name:n+" (Premium)",premium:!0};r&&(t.favorited=i.includes(e));const s=o.find((({country:t,premium:i})=>t===e&&i));if(s){const{delay:e,mark:i}=s;Object.assign(t,{delay:e,mark:i})}a.push(t)}}}return a.sort(((e,t)=>Boolean(e.favorited)!==Boolean(t.favorited)?e.favorited?-1:1:e.premium!==t.premium?e.premium?1:-1:e.name<t.name?-1:e.name>t.name?1:0))})(e,Re),this.premiumUser=i.premium,this.proxyCountry="proxy"===t.mode?t.country:null,this.proxyList=t.filters.filter((({disabled:e,proxyMode:t})=>!e&&t))}constructor(){super(),this.elementHighlight=this.elementHighlight.bind(this),this.keydownListener=Te.bind(this),this.country=null,this.domain="",this.highlightedCountry=null,this.proxyCountry="",this.proxyList=[]}async connectedCallback(){var e;super.connectedCallback(),this.charsBuffer=new z,document.addEventListener("keydown",this.keydownListener),await this.forceRenderAndGenerateNamesList();const t=null===(e=this.shadowRoot)||void 0===e?void 0:e.children,i=t[t.length-1];if(!i)throw new Error("index-locations: scrollElement does not exist");this.scrollElement=i,this.charsBuffer.addListener((e=>{let t=this.namesList.find((({name:t})=>t.startsWith(e)));if(!t)return;let{code:i,element:o,premium:n}=t;this.highlightedCountry={code:i,premium:n},this.scrollElement.scrollTop=o.offsetTop-2}));let o=(()=>{var e,t;const i=null===(e=this.shadowRoot)||void 0===e||null===(t=e.querySelector)||void 0===t?void 0:t.call(e,"div.Head");if(!i)throw new Error("index-locations: div.Head does not exist");return i.offsetHeight})();{var s,r;let e=null===(s=this.shadowRoot)||void 0===s||null===(r=s.querySelector)||void 0===r?void 0:r.call(s,"div.Sections");if(!e)throw new Error("index-locations: div.Sections does not exist");e.style.cssText=`top:${o}px;`}this.domain||(0,n.Z)({type:"сounters.increase",property:"popup: location page shows"})}disconnectedCallback(){super.disconnectedCallback(),document.removeEventListener("keydown",this.keydownListener)}updated(e){let t=Array.from(e.keys());if(e.has("countries")&&this.forceRenderAndGenerateNamesList(),t.some((e=>["domain","proxyCountry","proxyList"].includes(e)))){var i;let{domain:e,proxyCountry:t,proxyList:o}=this;if(!e)return void(this.country=t);this.country=(null===(i=o.find((t=>t.value===e)))||void 0===i?void 0:i.country)||""}}back(){E.Z.dispatch({type:"Page: set",page:"index:home"})}async countryClick({detail:{mode:e,country:t}}){if("change"===e)this.domain?await f.Z.siteFilters.changeCountry({domain:this.domain,country:t}):(await f.Z.setCountry(t),p.Z.partial({category:"extension",action:"change_country",label:t})),await new Promise((e=>{setTimeout(e,500)})),E.Z.dispatch({type:"Page: set",page:"index:home"});else if("premium"===e){const e=document.createElement("popup-premium");e.country=t,e.initiator="premium locations",e.style.cssText="top:-100%;",document.body.append(e),p.Z.partial({category:"premium",action:"show"});const i=await m,o=800;if("number"==typeof i&&i<=62){const t=-100,i=0;await g({duration:o,action:o=>{const n=o*(i-t)+t;e.style.cssText=`top:${n}%;`}})}else{const t=e.animate([{top:"-100%"},{top:"0"}],{duration:800,easing:"linear"});await new Promise((e=>{t.onfinish=e}))}e.style.cssText=""}}elementHighlight({premium:e,code:t}){return i=>{if(!Boolean(i.movementX||i.movementY))return;const o={premium:e,code:t};Ne.isEqual(this.highlightedCountry,o)||(this.highlightedCountry=o)}}favorite({detail:{favorited:e,country:t}}){e?s.add(t):s.remove(t)}async forceRenderAndGenerateNamesList(){await this.requestUpdate(),this.namesList=(()=>{var e,t,i;const o=this.countries.map((({code:e,name:t,premium:i})=>({code:e,name:t.toLowerCase(),premium:i}))),n=null===(e=this.shadowRoot)||void 0===e||null===(t=e.querySelector)||void 0===t||null===(i=t.call(e,"div.Sections"))||void 0===i?void 0:i.children,s=[];for(const e of n)"index-locations-element"===e.tagName.toLowerCase()&&s.push(e);return o.map(((e,t)=>Object.assign({element:s[t]},e)))})()}async openHelp(){const e=document.querySelector("div.MainContainer");if(!e)return;const t=document.createElement("popup-locations-information");t.style.cssText="opacity:0",e.appendChild(t);const i=await m;if("number"==typeof i&&i<=62){let e=0,i=1;await g({duration:400,action:o=>{let n=o*(i-e)+e;t.style.cssText=`opacity:${n};`}})}else{const e=t.animate([{opacity:0},{opacity:1}],{duration:400,easing:"linear"});await new Promise((t=>{e.onfinish=t}))}t.style.cssText=""}}customElements.define("index-locations",Me);const He=e=>(0,n.Z)({type:"ShowedOffers.includes",offer:e}),Ve=e=>(0,n.Z)({type:"ShowedOffers.push",offer:e}),Ue=y({changeLocation:"change_location",contactUs:"contact_us",home:"home",smartSettings:"smart_settings"});function We(){return o.dy`
  <style>
  ${d}
  a:link,
  a:visited{
    text-decoration: none;
    cursor: pointer;
    color: #7a7c7f;
  }
  a:hover{
    text-decoration: none;
    color: #3b9946;
  }

  :host{
    display: block;
    padding-top: 6px;
    margin-right: 70px;
  }
  :host > .E{
    display:inline-block;
    vertical-align:top;
    position: relative;
    color: #7a7c7f;
    cursor: pointer;
    font-size: 12px;
    line-height: 30px;
    margin: 0 0 0 17px;
  }
  :host > .E:hover{
    color: #3b9946;
  }
  :host > .E:first-of-type{
    margin-left: 0;
  }
  :host > .E.selected{
    color: #3b9946;
    cursor: default;
  }

  :host > .E::before{
    font-size: 14px;
    display: block;
    position: absolute;
    top: 0;
    left: 0;
    line-height: 30px;
  }

  :host > .E.home::before{
    content: '';
    display:inline-block;
    vertical-align:middle;
    background: url( '/images/menu/home.svg#grey' ) 0 0 no-repeat;
    background-size: 100% 100%;
    width: 12px;
    overflow:hidden;font-size:0;text-indent:-9999px;height:0;
    padding-top: 10px;
    position: static;
    margin-top: -3px;
    border-right: 3px solid transparent;
  }
  :host > .E.home.selected::before,
  :host > .E.home:hover::before{
    background-image: url( '/images/menu/home.svg#green' );
  }

  :host > .E.smartSettings{
    position: relative;
    padding-right: 21px;
    background: url( '/images/menu/settings_green.svg' ) 0 -5000px no-repeat;
  }
  :host > .E.smartSettings::before{
    content: '';
    display:inline-block;vertical-align:middle;
    background: url( '/images/menu/settings_grey.svg' ) 0 0 no-repeat;
    background-size: 100% 100%;
    width: 14px;
    overflow:hidden;font-size:0;text-indent:-9999px;height:0;
    padding-top:11px;
    position: static;
    margin-top: -3px;
    padding-right: 3px;
  }
  :host > .E.smartSettings:after{
    content: '';
    display: block;
    background: url( '/images/beta.svg' ) 0 0 no-repeat;
    background-size: 100% 100%;
    position: absolute;
    right: 0;
    top: 50%;
    margin-top: -16px;
    width: 18px;
    overflow:hidden;font-size:0;text-indent:-9999px;height:0;
    padding-top:18px;
  }
  :host > .E.smartSettings.selected::before,
  :host > .E.smartSettings:hover::before{
    background-image: url( '/images/menu/settings_green.svg' );
  }

  :host > .E.icon{
    width: 32px;
    min-height: 30px;
  }
  :host > .E.icon a{
    display: block;
    width: 32px;
    height: 0;
    padding-top: 32px;
    overflow: hidden;
    position: absolute;
    left: 0;
    top: calc(50% - 16px);
    margin-top: -1px;
    border-radius: 50%;
  }
  :host > .E.icon a::before{
    content: '';
    display: block;
    position: absolute;
  }
  :host > .E.icon a:focus{
    background-color: #e6e6e6;
  }

  :host > .E.support{
    margin-left: 7px;
    background: url( '/images/menu/mail_green.svg' ) 0 -5000px no-repeat;
  }
  :host > .E.support a::before{
    background: url('/images/menu/mail_grey.svg') 0 0 no-repeat;
    background-size: 100% 100%;
    width: 12px;
    overflow: hidden;
    padding-top: 9px;
    height: 0;
    top: calc(50% - 4px);
    left: calc(50% - 6px);
    margin-top: 1px;
  }
  :host > .E.support a:hover::before{
    background-image: url( '/images/menu/mail_green.svg' );
  }

  :host > .E.facebook{
    margin-left: 0;
    background: url( '/images/menu/facebook_green.svg' ) 0 -5000px no-repeat;
  }
  :host > .E.facebook a::before{
    background: url( '/images/menu/facebook_grey.svg' ) 0 0 no-repeat;
    background-size: 100% 100%;
    width: 8px;
    overflow: hidden;
    padding-top: 14px;
    height: 0;
    position: absolute;
    top: calc(50% - 7px);
    left: calc(50% - 4px);
    margin-top: 1px;
  }
  :host > .E.facebook a:hover::before{
    background-image: url( '/images/menu/facebook_green.svg' );
  }
  </style><!--
--><div class="E home ${this.homePage?"selected":""}" @click="${this.goHome}"><!--
 -->${Ue.home}<!--
--></div><!--
--><div
    class="E smartSettings ${this.filtersPage?"selected":""}"
    @click="${this.openSettings}"
    @contextmenu="${this.openSettings}"><!--
 -->${Ue.smartSettings}<!--
--></div><!--
--><div class="E icon support">
    <a href="${this.contactUsUrl}" target="_blank">
      ${Ue.contactUs}
    </a>
  </div><!--
--><div class="E icon facebook">
    <a href="${this.facebookUrl}" target="_blank">Facebook</a>
  </div>`}class qe extends((0,C.$)(E.Z)(o.oi)){render(){return We.call(this)}static get properties(){return{containsFilter:{type:Boolean},domain:{type:String},facebookUrl:{type:String},filtersPage:{type:Boolean},homePage:{type:Boolean}}}constructor(){super(),this.domain=null,this.filtersPage=!1,this.homePage=!1}connectedCallback(){super.connectedCallback();const e=this.shadowRoot;for(const t of e.childNodes)t.nodeType!==Node.ELEMENT_NODE&&t.remove();const t=e.querySelectorAll("a");for(const e of t)e.addEventListener("click",(async()=>{var e,t;await new Promise((e=>{setTimeout(e,50)})),null===(e=self)||void 0===e||null===(t=e.close)||void 0===t||t.call(e)}))}disconnectedCallback(){super.disconnectedCallback(),this.documentClick&&(document.removeEventListener("mousedown",this.documentClick),delete this.documentClick)}stateChanged({domain:e,pac:t,page:i}){this.containsFilter=(()=>{if(!e)return!1;return t.filters.filter((e=>!e.disabled&&"regex"!==e.format)).map((e=>e.value)).some((t=>t===e||e.endsWith("."+t)))})(),this.domain=(()=>{if(!e)return null;let i=t.filters.filter((e=>{let{disabled:t,format:i}=e;return!t&&"regex"!==i}));if(i.some((({value:t})=>t===e)))return e;let o=i.find((({format:t,value:i})=>"domain"===t&&e.endsWith("."+i)));if(o)return o.value;let n=window.domainZoneList.find((t=>e.endsWith("."+t)));return n?e.slice(0,-(n.length+1)).split(".").pop()+"."+n:e})(),this.filtersPage=(()=>{const e=i.split(":");return"index"===e[0]&&"filters"===e[1]})(),this.homePage=(()=>{const e=i.split(":");return"index"===e[0]&&"home"===e[1]})()}get contactUsUrl(){return F({storeState:E.Z.getStateSync(),url:R.Z.contactUs})}get facebookUrl(){return"https://www.facebook.com/BrowsecVPN"}goHome(){this.homePage||E.Z.dispatch({type:"Page: set",page:"index:home"})}async openSettings(e){if(e.preventDefault(),this.documentClick)return;(0,n.Z)({type:"сounters.increase",property:"popup: menu: smart settings click"}),(async()=>{if(await He("smart settings"))return;Ve("smart settings");const{pac:e,experiments:t}=await E.Z.getStateAsync(),i=t[c().experiments.firstSmartSettingTip.id];i&&p.Z.full({category:"Exp215FirstSsmenu_"+("1"===i?"B":"A"),action:"Open"}),e.filters.length||document.body.append(document.createElement("popup-help"))})();const{left:t}=e.target.getBoundingClientRect(),i=document.body.clientWidth-t,o=document.createElement("context-menu");o.style.cssText=`left:${t}px;max-width:${i}px;`,o.containsFilter=this.containsFilter,o.unicodeDomain=x.ZP.toUnicode(this.domain||""),o.domain=this.domain,document.body.append(o),this.documentClick=({target:e})=>{if(!(e instanceof HTMLElement))return;const t=!e.matches("div.Element");t&&(e===o||o.contains(e))||e.matches("popup-help, popup-help *")||(t&&o.remove(),this.documentClick&&(document.removeEventListener("mousedown",this.documentClick),delete this.documentClick))},document.addEventListener("mousedown",this.documentClick)}}customElements.define("index-menu",qe);const je=y({changeTimezoneByVirtualLocation:"change_timezone_according_to_virtual_location",dontShowPromoOffers:"dont_show_promo_offers",useBrowsecForWebrtcConnections:"use_browsec_for_webrtc_connections",webrtcSettingsControlledByAnotherExtension:"webrtc_settings_controlled_by_another_extension"});function Xe(){return o.dy`
  <style>
  ${d}
  .Checkboxes{
    padding: 17px 0 25px;
    font-size: 16px;
  }
  .Checkboxes > .E{
    position: relative;
    padding: 8px 20px;
  }
  .Checkboxes > .E.disabled{
    opacity: 0.5;
  }
  .Checkboxes > .E.highlighted{
    background: #f0f5f0;
  }
  .Checkboxes > .E > .In{
    display:inline-block;vertical-align:top;
    padding-right: 25px;
  }
  .Checkboxes > .E > .In::after{
    content:' ';clear:both;display:block;width:0;height:0;overflow:hidden;font-size:0;
  }
  .Checkboxes > .E > .In > checkbox-switch{
    float: left;
  }
  .Checkboxes > .E > .In > .R{
    display: block;
    margin-left: 55px;
  }

  .Information{
    display: inline-block;
    vertical-align: top;
    background: url( '/images/information_grey.svg' ) 0 0 no-repeat;
    background-size: 100% 100%;
    width: 16px;
    padding-top: 16px;
    overflow:hidden;font-size:0;text-indent:-9999px;height:0;
    cursor: pointer;
    margin: 4px 0 0 10px;
    position: relative;
  }
  .Information:hover{
    background-image: url( '/images/information_green.svg' );
  }
  .Information::after{
    content: '';
    display: block;
    background: url( '/images/information_green.svg' ) 0 -5000px no-repeat;
    width: 1px;
    height: 1px;
    overflow: hidden;
    position: absolute;
    left: 0;
    top: 0;
  }

  .Crown{
    background: url( '/images/crown.svg' ) 0 0 no-repeat;
    background-size: 100% 100%;
    width: 18px;
    overflow:hidden;font-size:0;text-indent:-9999px;height:0;
    padding-top: 18px;
    position: absolute;
    right: 20px;
    top: 10px;
  }

  .Error{
    clear: both;
    padding: 2px 0 0 55px;
    color: #c00;
    font-size: 12px;
  }


  .HealthCheck{
    position: absolute;
    bottom: 25px;
    left: 25px;
    right: 25px;
    text-align: center;
  }
  .HealthCheck_Button{
    display: inline-block;
    vertical-align: top;
    position: relative;
    font-size: 14px;
    line-height: 2.714;
    padding: 0 30px 0 50px;
    border: 1px solid #28344f;
    border-radius: 4px;
    color: #494b4d;
    cursor: pointer;
    text-align: left;
  }
  .HealthCheck_Button::after{
    content: '';
    display: block;
    background: url( '/images/diagnostics.svg#health_blue' ) 0 0 no-repeat;
    width: 19px;
    padding-top: 16px;
    height: 0;
    overflow: hidden;
    position: absolute;
    top: calc(50% - 16px / 2);
    left: 23px;
  }
  </style>

  <div class="Checkboxes">
  ${(()=>this.webrtcAvailable?o.dy`
    <div class="E ${this.webrtcNotEnoughPermissions?"highlighted":""}"><div class="In">
      <checkbox-switch
        .checked="${this.webrtcBlocked}"
        @click="${this.changeWebrtc}">
      </checkbox-switch>
      <div class="R">
        <label @click="${this.changeWebrtc}">${je.useBrowsecForWebrtcConnections}</label><!--
     --><div class="Information" @click="${this.showWebrtcHelp}"></div>
      </div>
        ${(()=>this.webrtcBlockedByOtherExtension?o.dy`
      <div class="Error">
        ${je.webrtcSettingsControlledByAnotherExtension}
      </div>`:"")()}
    </div></div>`:"")()}

    <div class="E ${this.changeDateDisabledClass} ${this.changeDateFirstTimeClass}"><div class="In">
      <checkbox-switch
        .checked="${this.hideDate}"
        data-changedate="true"
        @mouseover="${this.changeDateMouseover}"
        @click="${this.changeDate}">
      </checkbox-switch>
      <div class="R">
        <label
          data-changedate="true"
          @mouseover="${this.changeDateMouseover}"
          @click="${this.changeDate}"><!--
       -->${je.changeTimezoneByVirtualLocation}<!--
     --></label><!--
     --><div class="Information" @click="${this.showDateHelp}"></div>
      </div>
      <div class="Crown"></div>
    </div></div>

    <div class="E"><div class="In">
      <checkbox-switch
        .checked="${this.blockPromos}"
        data-changedate="true"
        @click="${this.changeBlockPromos}">
      </checkbox-switch>
      <div class="R">
        <label
          data-changedate="true"
          @click="${this.changeBlockPromos}"><!--
       -->${je.dontShowPromoOffers}<!--
     --></label>
      </div>
    </div></div>
  </div>

  <div class="HealthCheck"><!--
 --><div class="HealthCheck_Button" @click="${this.openDiagnostics}">Health check</div><!--
--></div>`}const Ge=e=>(0,n.Z)({type:"timezoneChange.set",value:e}),Ye=new class{constructor(){(async()=>{this.available=await(0,n.Z)({type:"webrtc.available"})})()}async disable(e){return e&&await e(),(0,n.Z)({type:"webrtc.disable"})}async enable(e){return e&&await e(),(0,n.Z)({type:"webrtc.enable"})}getControlState(){return(0,n.Z)({type:"webrtc.getControlState"})}};class Je extends o.oi{render(){return o.dy`
    <style>
    ${d}
    :host{
      display: block;
      width: 41px;
      height: 24px;
      cursor: pointer;
      position: relative;
    }
    :host::before{
      content: '';
      display: block;
      background: #e6e6e6;
      position: absolute;
      top: 3px;
      left: 0;
      right: 3px;
      overflow:hidden;font-size:0;text-indent:-9999px;height:0;
      padding-top:16px;
      border-radius: 8px;
      transition: background-color 0.15s ease-out 0s;
      box-shadow: inset 0 1px 2px rgba( 0, 0, 0, 0.2 );
    }
    :host(.checked)::before{
      background: #3b9946;
    }

    :host::after{
      content: '';
      display: block;
      width: 20px;
      overflow:hidden;font-size:0;text-indent:-9999px;height:0;
      padding-top:20px;
      background: #fff;
      border-radius: 50%;
      border: 1px solid #e8e8e8;
      box-shadow: 1px 1px 2px 0 rgba(0, 0, 0, 0.1);
      position: absolute;
      top: 0;
      left: 0;
      transition: left 0.15s ease-out 0s;
    }
    :host(.checked)::after{
      left: 17px;
    }
    </style>`}static get properties(){return{checked:{type:Boolean}}}updated(e){e.has("checked")&&this.classList.toggle("checked",this.checked)}}customElements.define("checkbox-switch",Je);const Ke=async()=>{if("undefined"!=typeof browser)return;if(!await new Promise(((e,t)=>{chrome.permissions.request({permissions:["privacy"]},(i=>{chrome.runtime.lastError?t(chrome.runtime.lastError):e(i)}))})))throw new Error("Management permission is not granted")};class Qe extends((0,C.$)(E.Z)(o.oi)){render(){return Xe.call(this)}static get properties(){return{blockPromos:{type:Boolean},changeDateDisabledClass:{type:String},changeDateFirstTimeClass:{type:String},hideDate:{type:Boolean},storeWebrtcBlocked:{type:Boolean},premiumUser:{type:Boolean},webrtcAvailable:{type:Boolean},webrtcBlocked:{type:Boolean},webrtcBlockedByOtherExtension:{type:Boolean},webrtcNotEnoughPermissions:{type:Boolean}}}stateChanged({promotionsBlock:e,timezoneChange:t,user:i,webrtcBlock:o}){this.changeDateDisabledClass=t&&!i.premium?"disabled":"",this.blockPromos=e,this.hideDate=t,this.premiumUser=i.premium,this.storeWebrtcBlocked=o}constructor(){super(),this.computeWebrtcNotEnoughPermissions=this.computeWebrtcNotEnoughPermissions.bind(this),this.changeDateFirstTimeClass="",(async()=>{let e=await u.Z.get("newSettingsFeatureTimezoneChange2");this.changeDateFirstTimeClass=e?"":"highlighted"})(),this.storeWebrtcBlocked=null,this.premiumUser=null,this.webrtcAvailable=Ye.available,this.webrtcBlocked=!1,this.webrtcBlockedByOtherExtension=!1,this.webrtcNotEnoughPermissions=!1}async connectedCallback(){super.connectedCallback(),await u.Z.set("newSettingsFeatureTimezoneChange2",!0)}disconnectedCallback(){super.disconnectedCallback(),this.tooltipElement&&(this.tooltipElement.remove(),delete this.tooltipElement),this.documentMouseMove&&(document.removeEventListener("mousemove",this.documentMouseMove),delete this.documentMouseMove)}firstUpdated(e){var t,i;super.firstUpdated(e),this.changeDateElements=Array.from((null===(t=this.shadowRoot)||void 0===t||null===(i=t.querySelectorAll)||void 0===i?void 0:i.call(t,'[data-changedate="true"]'))||[]),(async()=>{"not controlled"===await Ye.getControlState()&&(this.webrtcBlockedByOtherExtension=!0)})(),this.webrtcBlocked=!!E.Z.getStateSync().webrtcBlock&&ce.includes("privacy"),this.computeWebrtcNotEnoughPermissions(ce.get()),ce.addListener(this.computeWebrtcNotEnoughPermissions)}updated(e){e.has("webrtcBlocked")&&this.computeWebrtcNotEnoughPermissions(ce.get())}computeWebrtcNotEnoughPermissions(e){this.webrtcNotEnoughPermissions=(()=>null!==this.storeWebrtcBlocked&&(this.storeWebrtcBlocked&&!e.includes("privacy")))()}changeBlockPromos(){let e=!this.blockPromos;var t;t=e,(0,n.Z)({type:"promotionsBlock.set",value:t})}async changeDate(){if(!this.premiumUser&&this.hideDate)return;if(!this.premiumUser){const e=document.createElement("popup-premium");e.initiator="timezone change",e.style.cssText="top:-100%;",document.body.append(e),p.Z.partial({category:"premium",action:"show"});const t=await m,i=800;if("number"==typeof t&&t<=62){const t=-100,o=0;await g({duration:i,action:i=>{const n=i*(o-t)+t;e.style.cssText=`top:${n}%;`}})}else{const t=e.animate([{top:"-100%"},{top:"0"}],{duration:800,easing:"linear"});await new Promise((e=>{t.onfinish=e}))}return void(e.style.cssText="")}const e=!this.hideDate;await Ge(e),this.hideDate=e}changeDateMouseover({target:e}){if(this.premiumUser||!this.hideDate)return;if(this.changeDateTooltipShown)return;if(!(e instanceof HTMLElement))return;this.changeDateTooltipShown=!0;let{top:t,left:i,height:o}=e.getBoundingClientRect();t+=o+7,i-=14,i<10&&(i=10);let n=document.createElement("general-tooltip");n.text=(0,v.Z)("this_option_is_available_only_for_premium"),n.style.cssText=`top:${t}px;left:${i}px;`,this.tooltipElement=n,document.body&&document.body.append(n);let s=this.changeDateElements.concat([n]);this.documentMouseMove=e=>{let t=e.composedPath?e.composedPath():e.deepPath?e.deepPath():e.path||[e.target];s.some((e=>t.includes(e)))||(n.remove(),document.removeEventListener("mousemove",this.documentMouseMove),delete this.documentMouseMove,delete this.tooltipElement,this.changeDateTooltipShown=!1)},document.addEventListener("mousemove",this.documentMouseMove)}async changeWebrtc(){if(this.webrtcBlockedByOtherExtension)return;let e=!this.webrtcBlocked;try{e?await Ye.enable(Ke):await Ye.disable(Ke),this.webrtcBlocked=e}catch(e){Ze.Z.warn("WebRTC setup in popup failed")}}async openDiagnostics(){await(0,n.Z)({type:"Diagnostics.open"}),"undefined"!=typeof browser&&window.close()}showDateHelp(){this.showInformationPopup("date")}showWebrtcHelp(){this.showInformationPopup("webrtc")}async showInformationPopup(e){let t=document.querySelector("div.MainContainer");if(!t)return;let i=document.createElement("popup-description");i.theme=e,i.style.cssText="opacity:0",t.appendChild(i);const o=await m;if("number"==typeof o&&o<=62){const e=0,t=1;await g({duration:400,action:o=>{const n=o*(t-e)+e;i.style.cssText=`opacity:${n};`}})}else{const e=i.animate([{opacity:0},{opacity:1}],{duration:400,easing:"linear"});await new Promise((t=>{e.onfinish=t}))}i.style.cssText=""}}customElements.define("index-settings",Qe);const et=c().proxy.defaultCountry||"nl";function tt(e){return o.dy`
    <style>
    ${d}
    :host > .In{
      height: 100%;
      display: flex;
      align-items: center;
    }
    :host > .In > .In{}

    .Title{
      text-align: center;
      font-weight: bold;
      padding: 0 15px 15px;
      font-size: 16px;
    }
    .Text{
      text-align: center;
      padding: 0 15px 15px;
      font-size: 15px;
    }

    .ChangeRule{
      padding: 19px 14px;
      border-bottom: 1px solid #bcbcbc;
      display: flex;
      align-items: center;
    }
    .ChangeRule > .E{
      flex-grow: 0;
      flex-shrink: 0;
    }
    .ChangeRule > .E ~ .E{
      padding-left: 10px;
    }
    .ChangeRule > .E.input{
      flex-grow: 1;
    }

    .ChangeRule_Country{
      position: relative;
      width: 56px;
      border: 1px solid #bcbcbc;
      height: 22px;
      border-radius: 4px;
      padding: 1px 2px;
      background: url( '/images/smart_settings/arrow_up.svg' ) 0 -5000px no-repeat;
    }
    .ChangeRule_Country img{
      display: block;
      border-radius: 4px;
      filter: saturate(135%);
      opacity:0.7;
      border: 1px solid rgba(0, 0, 0, 0.22);
    }
    .ChangeRule_Country::after{
      content: '';
      display: block;
      background: url( '/images/smart_settings/arrow_down.svg' ) 0 0 no-repeat;
      background-size: 100% 100%;
      width: 9px;
      overflow:hidden;font-size:0;text-indent:-9999px;height:0;
      padding-top: 5px;
      position: absolute;
      top: 50%;
      right: 8px;
      margin-top: -2px;
    }
    .ChangeRule_Country.open{
      border-color: #3b9946;
    }
    .ChangeRule_Country.open::after{
      background-image: url( '/images/smart_settings/arrow_up.svg' );
    }
    .Off{
      width: 30px;
      line-height: 22px;
      padding-left: 1px;
      color: #994136;
      font-size: 14px;
      text-align: center;
    }

    .Buttons{
      display: flex;
      padding: 40px 15px 0;
      font-size: 14px;
    }
    .Buttons > .E{
      flex-grow: 1;
    }
    .Buttons > .E + .E{
      padding-left: 10px;
    }
    .ButtonDisagree,
    .ButtonAgree{
      line-height: 43px;
      text-align: center;
      border-radius: 4px;
      cursor: pointer;
    }
    .ButtonDisagree{
      border: 1px solid #3b9945;
      color: #3b9945;
    }
    .ButtonAgree{
      background: #3b9945;
      border: 1px solid #3b9945;
      color: #fff;
    }
    </style>

    <div class="In"><div class="In">
      <div class="Title">Did you use Browsec for particular website?</div>
      <div class="Text">
        Add it to SmartSettings, and next time you visit the website vpn will
        engage automatically for it.
      </div>

      <div class="ChangeRule">
        <div class="E text">${e.on}</div>
        <div class="E input">
          <filters-domain
            .value="${this.domain}"
            @value-changed="${this.inputListener}"
          ></filters-domain>
        </div>
        <div class="E text">${e.use}</div>
        <div class="E flag">
          <div class="ChangeRule_Country" @click="${this.openCountryList}">
          ${(()=>{if(!this.country)return o.dy`
            <div class="Off">${e.off}</div>`;const t=(({defaultCountry:e,country:t,countries:i})=>{let o=i.includes(t)?t:e;return"usw"===o&&(o="us"),"uk"===o&&(o="gb"),`/images/flags/${o}.svg`})({country:this.country,countries:this.countries,defaultCountry:et});return o.dy`
            <img src="${t}" width="30" height="20" alt=""/>`})()}
          </div>
        </div>
      </div>

      <div class="Buttons">
        <div class="E">
          <div class="ButtonDisagree" @click=${this.cancel}>
            Nah. Just switch off
          </div>
        </div>
        <div class="E">
          <div class="ButtonAgree" @click=${this.save}>
            Add to list and switch vpn off
          </div>
        </div>
      </div>

    </div></div>`}const it="undefined"!=typeof browser?browser:chrome,ot=y({off:"off",on:"on",pleaseEnterDomain:"please_enter_domain",pleaseEnterValidDomain:"please_enter_valid_domain",use:"use"}),nt=({dimensionElement:e,text:t})=>{const i=document.createElement("tooltip-error");i.text=t;const o=e.getBoundingClientRect(),n=o.top+e.offsetHeight-1;i.style.cssText=`top:${n}px;left:${o.left}px;`,document.body.append(i);const s=(()=>{let e=!0;return()=>{e?e=!1:(i.remove(),document.removeEventListener("click",s))}})();document.addEventListener("click",s)};class st extends((0,C.$)(E.Z)(o.oi)){render(){return tt.call(this,ot)}static get properties(){return{country:{type:String},domain:{type:String}}}constructor(){super(),this.countries=[],this.country=null,this.domain=""}async firstUpdated(e){super.firstUpdated(e);const t=this.shadowRoot,i=t.querySelector("div.ChangeRule_Country");if(!i)throw new Error("No countryElement element in smart-settings-hint");this.countryElement=i;const o=t.querySelector("filters-domain");if(!o)throw new Error("No inputElement element in smart-settings-hint");this.inputElement=o}stateChanged({proxyServers:e}){this.countries=Array.from(e.freeCountries())}cancel(){p.Z.full({category:"Exp215AddSs",action:"Reject",label:this.domain}),E.Z.dispatch({type:"Page: set",page:"index:home"})}inputListener({detail:{value:e}}){this.domain=e}openCountryList(){this.countryElement.classList.add("open");const e=document.createElement("filters-country-list");e.countries=this.countries.map((e=>({code:e,name:it.i18n.getMessage("country_name_"+e.toUpperCase())}))).sort((({name:e},{name:t})=>e<t?-1:e>t?1:0)),e.country=this.country,e.addEventListener("select",(({detail:e})=>{this.country=e,this.countryElement.classList.remove("open")})),e.addEventListener("disable",(()=>{this.country=null,this.countryElement.classList.remove("open")}));const{left:t,top:i}=this.countryElement.getBoundingClientRect(),o=this.countryElement.offsetHeight,n=i+o,s=window.innerWidth-t-this.countryElement.offsetWidth,r=window.innerHeight-i-o;e.style.cssText=`top:${n}px;right:${s}px;max-height:${r}px;`,document.body.append(e),this.documentClick=({target:t})=>{t instanceof HTMLElement&&(e.contains(t)||t===e)||(e.remove(),this.documentClick&&(document.removeEventListener("mousedown",this.documentClick),delete this.documentClick,this.countryElement.classList.remove("open")))},document.addEventListener("mousedown",this.documentClick)}async save(){const{country:e,domain:t}=this;if(!t)return void nt({dimensionElement:this.inputElement,text:ot.pleaseEnterDomain});const i=x.ZP.toASCII(t);if(void 0!==i)if(1!==i.split(".").length){{const e=i.split("."),t=4===e.length&&e.every((e=>/^[0-9]+$/.test(e)&&Number(e)>=0&&Number(e)<=255));if(!t&&e.some((e=>!/^[a-zA-Z0-9-_]+$/.test(e))))return void nt({dimensionElement:this.inputElement,text:ot.pleaseEnterValidDomain});if(!t){const e=i.split(".").pop();if(!window.domainZoneList.includes(e))return void nt({dimensionElement:this.inputElement,text:ot.pleaseEnterValidDomain})}}p.Z.full({category:"Exp215AddSs",action:"Confirm",label:i}),e?await f.Z.siteFilters.add({country:e,domain:i,type:"proxy"}):await f.Z.siteFilters.add({domain:i,type:"direct"}),(0,n.Z)({type:"сounters.increase",property:"popup: smart settings: add rule"}),E.Z.dispatch({type:"Page: set",page:"index:home"}),document.body.append(document.createElement("smart-settings-hint-done")),p.Z.full({category:"Exp215SsMenuHint",action:"View"})}else nt({dimensionElement:this.inputElement,text:ot.pleaseEnterValidDomain})}}customElements.define("smart-settings-hint",st);const rt=y({on:"on",off:"off"});class at extends o.oi{render(){return o.dy`
    <style>
    ${d}
    :host{
      display: block;
      width: 61px;
      height: 26px;
      cursor: pointer;
      position: relative;
    }
    :host *{
      cursor: pointer;
    }
    .BackgroundText{
      display: block;
      background: #994136;
      border-radius: 13px;
      width: 61px;
      height: 26px;
      line-height: 26px;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.12) inset, 0 0 2px rgba(0, 0, 0, 0.15) inset;
      font-size: 13px;
      height: inherit;
      position: relative;
      text-transform: uppercase;
      transition: all 0.15s ease-out 0s;
    }
    .BackgroundText_Off,
    .BackgroundText_On{
      position: absolute;
      top: 0;
      transition: inherit;
    }
    .BackgroundText_Off{
      color: #fff;
      right: 8px;
    }
    .BackgroundText_On{
      color: white;
      left: 11px;
      opacity: 0;
      text-shadow: 0 1px rgba(0, 0, 0, 0.2);
    }
    :host(.on) .BackgroundText{
      background: #3b9946;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.15) inset, 0 0 3px rgba(0, 0, 0, 0.2) inset;
    }
    :host(.on) .BackgroundText_Off{
      opacity: 0;
    }
    :host(.on) .BackgroundText_On{
      opacity: 1;
    }

    .Circle{
      background: #fff;
      border-radius: 11px;
      height: 22px;
      width: 22px;
      left: 2px;
      position: absolute;
      top: 2px;
      transition: left 0.15s ease-out 0s;
    }
    .Circle:before{
      content: "";
      background: #f9f9f9 linear-gradient(to bottom, #eeeeee, white) repeat scroll 0 0;
      border-radius: 6px;
      box-shadow: 0 1px rgba(0, 0, 0, 0.02) inset;
      height: 12px;
      left: 50%;
      margin: -6px 0 0 -6px;
      position: absolute;
      top: 50%;
      width: 12px;
    }
    :host(.on) .Circle{
      box-shadow: -1px 1px 5px rgba(0, 0, 0, 0.2);
      left: 37px; /* left: auto; right: 2px; */
    }
    </style>

    <div class="BackgroundText">
      <div class="BackgroundText_Off">${this.translations.off}</div>
      <div class="BackgroundText_On">${this.translations.on}</div>
    </div>
    <div class="Circle"></div>`}static get properties(){return{on:{type:Boolean,observer:"observeOn"},translations:{type:Object}}}get translations(){return rt}updated(e){e.has("on")&&this.classList.toggle("on",this.on)}}customElements.define("c-switch",at);const lt=c().proxy.defaultCountry||"nl";class ct extends((0,C.$)(E.Z)(o.oi)){render(){return q.call(this)}static get properties(){return{page:{type:String},preMenuView:{type:String},switchOn:{type:Boolean}}}constructor(){super(),this.page=E.Z.getStateSync().page,this.preMenuView="",this.switchOn=!1}firstUpdated(e){super.firstUpdated(e);const t=this.shadowRoot.querySelector("div.Switch");if(!t)throw new Error("main-index shadowRoot is empty");this.switch=t,this.switch.append(document.createElement(E.Z.getStateSync().page.replace(/\:/g,"-")))}async updated(e){if(!e.has("page"))return;const t=this.page,i=e.get("page");if(!i)return;const o=t.split(":"),n=i.split(":");if("index"!==o[0])return;const s=E.Z.getStateSync().pac.mode,r=o.slice(1),a=n.slice(1),l="home"===r[0]?"left":"right",c=r[0]===a[0],d=this.switch.firstElementChild;if(!d)throw new Error("main-index has no child elements");if(c){if("filters"===r[0]&&r[1]){const e=r[1];d.country="proxy"===s?null:lt,d.domain=e,d.selectedDomain=null}}else{const e=(()=>{switch(r[0]){case"filters":return"index-filters";case"home":return"index-home";case"locations":return"index-locations";case"settings":return"index-settings";case"smart settings hint":return"smart-settings-hint"}})();if(!e)return;const t=document.createElement(e);"locations"===r[0]&&r[1]&&(t.domain=r[1]),"filters"===r[0]&&r[1]&&(t.domain=r[1],t.country="proxy"===s?null:lt),"left"===l?(this.switch.prepend(t),this.switch.style.cssText="margin-left:-100%;"):this.switch.append(t),"undefined"==typeof browser&&await new Promise((e=>{setTimeout(e,0)}));const i=250,o=await m;if("number"==typeof o&&o<=62){const e="left"===l?-100:0,t="left"===l?0:-100;await g({duration:i,action:i=>{const o=i*(t-e)+e;this.switch.style.cssText=`margin-left:${o}%;`}})}else{const e=this.switch.animate([{marginLeft:"left"===l?"-100%":"0%"},{marginLeft:"left"===l?"0%":"-100%"}],{duration:i,easing:"linear"});await new Promise(((t,i)=>{e.onfinish=t}))}if(d.remove(),this.switch.style.cssText="","undefined"!=typeof browser&&"index-locations"===e){var p,u,h;const e=null===(p=t.shadowRoot)||void 0===p||null===(u=p.querySelector)||void 0===u?void 0:u.call(p,".In");null==e||null===(h=e.focus)||void 0===h||h.call(e)}}}stateChanged({domain:e,pac:t,page:i}){this.page=i,this.preMenuView=(()=>{const[o,n]=i.split(":");if("index"===o&&"filters"===n)return"help";if("index"===o&&"smart settings hint"===n)return"help";if(!e)return"switch";const s=[];for(const e of t.filters)e.disabled||"regex"===e.format||s.push(e.value);return s.includes(e)?"":"switch"})(),this.switchOn="proxy"===t.mode}openHelp(){(0,n.Z)({type:"сounters.increase",property:"popup: smart settings: open help"}),(0,n.Z)({type:"create tab",options:"/pages/help/help.html"})}async switchClick(){const e=new U.Z("Big switch from "+(this.switchOn?"on":"off"));this.switchOn?await f.Z.disable():await f.Z.enable(),e.end()}}customElements.define("main-index",ct);class dt extends((0,C.$)(E.Z)(HTMLElement)){constructor(){super(),this.animation=!1,this.indexPage="index"===E.Z.getStateSync().page.split(":")[0];const e=this.attachShadow({mode:"open"}),t=ue.dy`
    <style>
    ${d}
    :host{
      display: block;
      overflow: hidden;
      position: absolute;
      top:56px;
      width: 100%;
      bottom:0px;
      left:0px;
      text-align: left;
    }
    :host > .In{
      width: 100%;
      height: 100%;
      white-space: nowrap;
    }
    :host > .In > *{
      width: 100%;
      height: 100%;
      position: relative;
      display:inline-block;
      vertical-align:top;
      white-space:normal;
      overflow: hidden;
    }
    </style>

    <div class="In"></div>`;(0,he.sY)(t,e,{scopeName:this.tagName.toLowerCase()}),this.ribbon=e.querySelector("div.In"),this.ribbon.append(document.createElement("main-index"))}async stateChanged({page:e}){const t=this.indexPage,i="index"===e.split(":")[0];if(i===t)return;var o,n;(this.indexPage=i,this.animation)?null===(o=this.animationObject)||void 0===o||null===(n=o.cancel)||void 0===n||n.call(o):this.animation=!0;for(const e of this.ribbon.children)"true"===e.dataset.old&&e.remove();const s=this.ribbon.lastElementChild;s.dataset.old="true";const r=document.createElement(i?"main-index":"main-login");r.style.cssText="visibility:hidden;",i?this.ribbon.prepend(r):this.ribbon.append(r),await r.updateComplete,i&&(this.ribbon.style.cssText="margin-left:-100%;"),await new Promise((e=>{setTimeout(e,0)})),r.style.cssText="";const a=await m;try{var l;if("number"==typeof a&&a<=62){let e;const t=performance.now();await new Promise(((o,n)=>{this.animationObject={cancel:()=>{cancelAnimationFrame(e),n(new Error("page-switch animation is broken"))}};const s=i?-100:0,r=i?0:-100,a=i=>{if(i-t>=250)return void o();const n=(i-t)/250*(r-s)+s;this.ribbon.style.cssText=`margin-left:${n}%;`,e=requestAnimationFrame(a)};e=requestAnimationFrame(a)}))}else{const e=this.ribbon.animate([{marginLeft:i?"-100%":"0%"},{marginLeft:i?"0%":"-100%"}],{duration:250,easing:"linear"});this.animationObject=e,await new Promise(((t,i)=>{e.onfinish=t,e.oncancel=()=>{i(new Error("page-switch animation is broken"))}}))}s.remove(),this.ribbon.style.cssText="",null===(l=r.onAnimationComplete)||void 0===l||l.call(r),this.animation=!1}catch(e){}}}customElements.define("page-switch",dt);const pt=y({changeTimezone:{p1:"change_timezone_text_1",p2:"change_timezone_text_2",p3:"change_timezone_text_3"},whatIsWebrtc:{title:"what_is_webrtc_title",p1:"what_is_webrtc_text_1",p2:"what_is_webrtc_text_2",p3:"what_is_webrtc_text_3"}});class ut extends o.oi{render(){return o.dy`
    <style>
    ${d}
    :host{
      display: block;
      font-size: 14px;
      line-height: 1.3;
      color: #28344f;
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      z-index: 2;
    }
    :host > .Overlay{
      position: absolute;
      top:0px;right:0px;bottom:0px;left:0px;
      overflow: hidden;
      text-indent: -9999px;
      font-size: 0;
      background: rgba(255, 255, 255, 0.5);
    }
    :host > .In{
      position: absolute;
      top:56px;
      right:0px;
      bottom:40px;
      left:0px;
      border: 1px solid transparent;
      border-width: 6px 5px 5px;
    }
    :host > .In > .Bg{
      position: absolute;
      top: 0;
      right: 0;
      bottom: 0;
      left: 0;
      background: #fff;
      box-shadow: 0 1px 5px 0 rgba(0, 0, 0, 0.3);
      border-radius: 4px;
      font-size: 0;
      overflow: hidden;
    }

    :host > .In > .In{
      position: relative;
      width: 100%;
      height: 100%;
    }
    :host > .In > .In > .In{
      position: absolute;
      left: 20px;
      right: 20px;
      top: 25px;
      bottom: 20px;
      overflow: auto;
    }
    :host > .In > .In > .In::-webkit-scrollbar{
      width: 6px;
    }
    :host > .In > .In > .In::-webkit-scrollbar-track{
      border-radius: 3px;
      background: rgba(255,255,255,0);
    }
    :host > .In > .In > .In::-webkit-scrollbar-thumb{
      border-radius: 3px;
      background: #aaa;
    }

    .Text{
      color: #28344f;
      font-size: 14px;
      line-height: 1.375;
    }
    .Title{
      font-size: 18px;
      font-weight: 600;
      padding-bottom: 15px;
    }
    .Text p + p{
      padding-top: 1em;
    }

    .Close{
      background: url( '/images/popup_close_grey.svg' ) 0 0 no-repeat;
      background-size: 100% 100%;
      width: 12px;
      overflow:hidden;font-size:0;text-indent:-9999px;height:0;
      padding-top:12px;
      position: absolute;
      right: 11px;
      top: 11px;
      border: 5px solid transparent;
      cursor: pointer;
    }
    .Close:hover{
      background-image: url( '/images/popup_close_black.svg' );
    }
    .Close::after{
      content: '';
      display: block;
      width: 1px;
      height: 1px;
      overflow: hidden;
      position: absolute;
      top: 0;
      left: 0;
      background: url( '/images/popup_close_black.svg' ) 0 -5000px no-repeat;
    }
    </style>

    <div class="Overlay" @click="${this.close}">&nbsp;</div>
    <div class="In">
      <div class="Bg"></div>
      <div class="In">
        <div class="In Text">
  ${(()=>"date"===this.theme?o.dy`
          <p>${pt.changeTimezone.p1}</p>
          <p>${pt.changeTimezone.p2}</p>
          <p>${pt.changeTimezone.p3}</p>`:"webrtc"===this.theme?o.dy`
          <div class="Title">${pt.whatIsWebrtc.title}</div>
          <p>${pt.whatIsWebrtc.p1}</p>
          <p>${pt.whatIsWebrtc.p2}</p>
          <p>${pt.whatIsWebrtc.p3}</p>`:"")()}
        </div>
        <div class="Close" @click="${this.close}">X</div>
      </div>
    </div>
    `}static get properties(){return{theme:{type:String}}}constructor(){super(),this.theme=""}async close(){const e=await m;if("number"==typeof e&&e<=62){let e=1,t=0;await g({duration:400,action:i=>{let o=i*(t-e)+e;this.style.cssText=`opacity:${o};`}})}else{let e=this.animate([{opacity:1},{opacity:0}],{duration:400,easing:"linear"});await new Promise((t=>{e.onfinish=t}))}this.remove()}}customElements.define("popup-description",ut);const ht=[{currency:"USD",value:71.99,duration:24}],gt=y({getPremiumNow:"get_premium_now",moneyBackGuarantee:"7_days_money_back_guarantee"});function mt(){const e=(0,v.Z)("only_X_per_month").replace(/XXX/g,this.currency+this.price);return o.dy`
  <style>
  ${d}
  :host{
    display: block;
    position: absolute;
    z-index: 3;
    top:0px;
    right:0px;
    left:0px;
    height: 100%;
    background: #fff;
  }

  .Head{
    background: #28344f;
    color: #fff;
    text-align: center;
    font-size: 17px;
    line-height: 36px;
    font-weight: 500;
    position: relative;
    padding: 9px 10px 9px;
    height: auto;
    overflow: visible;
  }

  .Title{
    text-align: center;
    font-weight: bold;
    color: #1c304e;
    padding: 15px 15px 0;
    font-size: 17px;
  }
  .Text{
    text-align: center;
    color: #1c304e;
    padding: 30px 15px 0;
    font-size: 15px;
  }

  .Button_Out{
    padding: 30px 5px 0;
  }
  .Button{
    display: table;
    width: 100%;
    height: 60px;
    background: #3d973f;
    text-align: center;
    border-radius: 4px;
    position: relative;
  }
  .Button:link,
  .Button:visited,
  .Button:hover,
  .Button:active{
    color: #fff;
    text-decoration: none;
  }
  .Button *{
    cursor: pointer;
  }
  .Button > .In{
    display: table-cell;
    vertical-align: middle;
  }

  .Button_Name{
    display: block;
    font-weight: 600;
    font-size: 18px;
    text-transform: uppercase;
  }
  .Button_Price{
    display: block;
    font-size: 14px;
  }

  .Guarantee{
    color: #808080;
    font-size: 12px;
    text-align: center;
    padding-top: 7px;
  }

  .SlowConnection{
    padding: 50px 5px 0;
  }
  .SlowConnection input[type="button"]{
    box-sizing: border-box;
    display: block;
    width: 100%;
    border: 1px solid #999999;
    height: 60px;
    background: #d8d8d8;
    border-radius: 4px;
    color: #1c304e;
    cursor: pointer;
    font-size: 18px;
    text-align: center;
  }
  .SlowConnection input[type="button"]:hover{
    border-color: #000;
  }
  </style>

  <div class="Head">Browsec Premium</div>

  <div class="Title">
    Your free access to our fast servers<br />has expired
  </div>
  <div class="Text">
    To continue using high-speed protected connection subscribe to Browsec Premium
  </div>

  <div class="Button_Out">
    <a href="${this.premiumLink}" class="Button" target="_blank" @click=${this.buyClick}>
      <span class="In">
        <span class="Button_Name">${gt.getPremiumNow}</span>
        <span class="Button_Price">${e}</span>
      </span>
    </a>
  </div>
  <div class="Guarantee">${gt.moneyBackGuarantee}</div>

  <div class="SlowConnection">
    <input type="button" value="Slow down my connection" @click=${this.closeClick}/>
  </div>`}class ft extends((0,C.$)(E.Z)(o.oi)){render(){return mt.call(this)}stateChanged({experiments:e,prices:t,priceTrial:i}){const{currency:o,price:n}=ye({prices:t,priceTrial:i});this.currency=o,this.price=n}get premiumLink(){var e;const t=E.Z.getStateSync(),i=Date.now(),o=t.promotions.find((({from:e,till:t,tariffs:o})=>e<=i&&i<=t&&o)),n=null!==(e=null==o?void 0:o.id)&&void 0!==e?e:"default_campaign",s=(()=>{if(!o)return ht;const{tariffs:e}=o;if(!e)throw new Error('No "tariffs" property in tariff');return e.map((({price:{currency:e,value:t},duration:i})=>({currency:e,duration:i,value:t})))})().map((({duration:e,value:t})=>({duration:e,pricePerMonth:t/e}))).sort((({pricePerMonth:e},{pricePerMonth:t})=>e-t)),r={feature:"fast_servers",plan_id:(()=>{switch(s[0].duration){case 1:return"monthly";case 12:return"annual";case 24:return"biennial";default:throw new Error("Incorrect duration")}})(),utm_source:"chromium extension",utm_medium:"premium_div",utm_campaign:n,utm_term:(0,v.Z)("get_premium_now")+" "+(0,v.Z)("only_X_per_month").replace(/XXX/g,this.currency+this.price)};{const e=t.experiments[c().experiments.fastServersWarning.id],i=(()=>{switch(e){case"0":return"178_a";case"1":return"178_b";case"2":return"178_c";case"3":return"178_d"}})();i&&Object.assign(r,{expvarid:i})}return F({action:e=>Object.assign(e,r),storeState:t,url:(null==o?void 0:o.clickUrl)||R.Z.premium})}async buyClick(){var e,t;p.Z.full({category:"Exp178",action:"NewPayWall",label:"Click"}),await new Promise((e=>{setTimeout(e,50)})),null===(e=self)||void 0===e||null===(t=e.close)||void 0===t||t.call(e)}async closeClick(){p.Z.full({category:"Exp178",action:"NewPayWall",label:"Close"});const e=await m;if("number"==typeof e&&e<=62){const e=0,t=-100;await g({duration:800,action:i=>{const o=i*(t-e)+e;this.style.cssText=`top:${o}%;`}})}else{const e=this.animate([{top:0},{top:"-100%"}],{duration:800,easing:"linear"});await new Promise((t=>{e.onfinish=t}))}this.remove()}}customElements.define("fast-servers-expired",ft);class xt extends o.oi{render(){return o.dy`
    <style>
    ${d}
    :host{
      display: block;
      font-size: 14px;
      line-height: 1.3;
      color: #28344f;
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      z-index: 4;
    }
    :host > .Overlay{
      position: absolute;
      top:0px;right:0px;bottom:0px;left:0px;
      overflow: hidden;
      text-indent: -9999px;
      font-size: 0;
    }
    :host > .In{
      position: absolute;
      top:56px;
      right:0px;
      bottom:40px;
      left:0px;
      border: 1px solid transparent;
      border-width: 6px 5px 5px;
    }
    :host > .In::before{
      content: '';
      display: block;
      position: absolute;
      top: 0;
      right: 0;
      bottom: 0;
      left: 0;
      background: #fff;
      box-shadow: 0 1px 5px 0 rgba(0, 0, 0, 0.3);
      border-radius: 4px;
      font-size: 0;
      overflow: hidden;
    }
    :host > .In > .In{
      position: relative;
      display: flex;
      align-items: center;
      height: 100%;
    }
    :host > .In > .In > .In{
      padding: 0 20px;
      flex-grow: 1;
    }

    .Img{
      background: url( '/images/exp178_congrats.svg' ) 50% 50% no-repeat;
      background-size: 100% 100%;
      width: 84px;
      height: 82px;
      margin: 0 auto;
      border-bottom: 17px solid transparent;
    }

    .Title{
      font-size: 18px;
      padding-bottom: 15px;
      font-weight: 600;
      text-align: center;
    }
    .Description{
      text-align: center;
    }
    .Description p{
      padding: 0;
    }
    .Description p ~ p{
      padding-top: 1.5em;
    }
    
    .Button{
      text-align: center;
      padding-top: 17px;
    }
    .Button input{
      display:inline-block;
      vertical-align:top;
      box-sizing: content-box;
      height: 45px;
      line-height: 45px;
      border: 0;
      cursor: pointer;
      min-width: 200px;
      padding: 0 15px;
      background: #3b9946;
      text-align: center;
      border-radius: 5px;
      color: #fff;
      font-size: 16px;
      font-weight: 600;
    }
    </style>

    <div class="Overlay">&nbsp;</div>
    <div class="In"><div class="In"><div class="In">
      <div class="Img"></div>
      <div class="Title">Congrats!</div>
      <div class="Description">
        <p>
          We have a special gift for you — <br />
          7 days of free access to our faster servers. 
        </p>
        <p>
          <b>Use safe internet at a higher speed!</b>
        </p>
      </div>
      <div class="Button"><!--
      --><input type="button" value="OK, I got it" @click="${this.close}"/><!--
    --></div>
    </div></div></div>
    `}async close(){p.Z.full({category:"Exp178",action:"Congrats",label:"Click"});const e=await m;if("number"==typeof e&&e<=62){const e=1,t=0;await g({duration:400,action:i=>{const o=i*(t-e)+e;this.style.cssText=`opacity:${o};`}})}else{const e=this.animate([{opacity:1},{opacity:0}],{duration:400,easing:"linear"});await new Promise((t=>{e.onfinish=t}))}this.style.cssText="display:none",this.remove()}}customElements.define("fast-servers-initial",xt);const vt=y({okIGotIt:"ok_i_got_it",smartSettingsControl:"smart_settings_allow_you_to_control",smartSettingsFeatures1:"smart_settings_features_1",smartSettingsFeatures2:"smart_settings_features_2",smartSettingsFeatures3:"smart_settings_features_3",withSmartSettingsYouCan:"with_smart_settings_you_can"});class bt extends o.oi{render(){return o.dy`
    <style>
    ${d}
    :host{
      display: block;
      font-size: 14px;
      line-height: 1.3;
      color: #28344f;
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      z-index: 4;
    }
    :host > .Overlay{
      position: absolute;
      top:0px;right:0px;bottom:0px;left:0px;
      overflow: hidden;
      text-indent: -9999px;
      font-size: 0;
    }
    :host > .In{
      position: absolute;
      top:56px;
      right:0px;
      bottom:40px;
      left:0px;
      border: 1px solid transparent;
      border-width: 6px 5px 5px;
    }
    :host > .In > .Bg{
      position: absolute;
      top: 0;
      right: 0;
      bottom: 0;
      left: 0;
      background: #fff;
      box-shadow: 0 1px 5px 0 rgba(0, 0, 0, 0.3);
      border-radius: 4px;
      font-size: 0;
      overflow: hidden;
    }
    :host > .In > .In{
      position: relative;
      padding: 27px 20px;
    }

    .Title{
      font-size: 18px;
      padding-bottom: 15px;
      font-weight: 600;
    }
    .Description{
      padding-bottom: 20px;
    }
    ul{
      list-style: none;
    }
    ul > li{
      padding-left: 20px;
      position: relative;
    }
    ul > li::after{
      content: '';
      display: block;
      background: url('/images/popup-help/check.svg') 0 0 no-repeat;
      background-size: 100% 100%;
      width: 14px;
      overflow:hidden;font-size:0;text-indent:-9999px;height:0;
      padding-top:10px;
      position: absolute;
      top: 5px;
      left: 0;
    }
    ul > li + li{
      border-top: 7px solid transparent;
    }
    .Button{
      text-align: center;
      padding-top: 15px;

    }
    .Button input{
      display:inline-block;
      vertical-align:top;
      box-sizing: content-box;
      height: 45px;
      line-height: 45px;
      border: 0;
      cursor: pointer;
      min-width: 200px;
      padding: 0 15px;
      background: #3b9946;
      text-align: center;
      border-radius: 5px;
      color: #fff;
      font-size: 16px;
      font-weight: 600;
    }

    .Close{
      position: absolute;
      top: 16px;
      right: 16px;
      background: url( '/images/popup_close_grey.svg' ) 0 0 no-repeat;
      background-size: 100% 100%;
      width: 12px;
      overflow:hidden;font-size:0;text-indent:-9999px;height:0;
      padding-top:12px;
      cursor: pointer;
    }
    .Close:hover{
      background-image: url( '/images/popup_close_black.svg' );
    }
    .Close::after{
      content: '';
      display: block;
      width: 1px;
      height: 1px;
      overflow: hidden;
      position: absolute;
      top: 0;
      left: 0;
      background: url( '/images/popup_close_black.svg' ) 0 -5000px no-repeat;
    }
    </style>

    <div class="Overlay">&nbsp;</div>
    <div class="In">
      <div class="Bg"></div>
      <div class="In">
        <div class="Title">${vt.smartSettingsControl}</div>
        <div class="Description">${vt.withSmartSettingsYouCan}</div>
        <div class="Features">
          <ul>
            <li>${vt.smartSettingsFeatures1}</li>
            <li>${vt.smartSettingsFeatures2}</li>
            <li>${vt.smartSettingsFeatures3}</li>
          </ul>
        </div>
        <div class="Button"><input type="button" value="${vt.okIGotIt}" @click="${this.close}"/></div>
        <div class="Close" @click="${this.close}">X</div>
      </div>
    </div>
    `}async close(e){e.stopPropagation();const t=await m;if("number"==typeof t&&t<=62){let e=1,t=0;await g({duration:400,action:i=>{let o=i*(t-e)+e;this.style.cssText=`opacity:${o};`}})}else{let e=this.animate([{opacity:1},{opacity:0}],{duration:400,easing:"linear"});await new Promise((t=>{e.onfinish=t}))}this.style.cssText="display:none"}}customElements.define("popup-help",bt);const yt=y({text1:"locations_help_1",text2:"locations_help_2",text3:"locations_help_3"});class wt extends o.oi{render(){return o.dy`
    <style>
    ${d}
    :host{
      display: block;
      font-size: 14px;
      line-height: 1.3;
      color: #28344f;
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      z-index: 2;
    }
    :host > .Overlay{
      position: absolute;
      top:0px;right:0px;bottom:0px;left:0px;
      overflow: hidden;
      text-indent: -9999px;
      font-size: 0;
      background: rgba(255, 255, 255, 0.5);
    }
    :host > .In{
      position: absolute;
      top:56px;
      right:0px;
      bottom:40px;
      left:0px;
      border: 1px solid transparent;
      border-width: 6px 5px 5px;
    }
    :host > .In > .Bg{
      position: absolute;
      top: 0;
      right: 0;
      bottom: 0;
      left: 0;
      background: #fff;
      box-shadow: 0 1px 5px 0 rgba(0, 0, 0, 0.3);
      border-radius: 4px;
      font-size: 0;
      overflow: hidden;
    }

    :host > .In > .In{
      position: relative;
      width: 100%;
      height: 100%;
    }
    :host > .In > .In > .In{
      position: absolute;
      left: 20px;
      right: 20px;
      top: 25px;
      bottom: 20px;
      overflow: auto;
    }
    :host > .In > .In > .In::-webkit-scrollbar{
      width: 6px;
    }
    :host > .In > .In > .In::-webkit-scrollbar-track{
      border-radius: 3px;
      background: rgba(255,255,255,0);
    }
    :host > .In > .In > .In::-webkit-scrollbar-thumb{
      border-radius: 3px;
      background: #aaa;
    }

    .Text{
      color: #28344f;
      font-size: 14px;
      line-height: 1.375;
    }
    .Title{
      font-size: 18px;
      font-weight: 600;
      padding-bottom: 15px;
    }
    .Text p + p{
      padding-top: 1em;
    }

    .Close{
      background: url( '/images/popup_close_grey.svg' ) 0 0 no-repeat;
      background-size: 100% 100%;
      width: 12px;
      overflow:hidden;font-size:0;text-indent:-9999px;height:0;
      padding-top:12px;
      position: absolute;
      right: 11px;
      top: 11px;
      border: 5px solid transparent;
      cursor: pointer;
    }
    .Close:hover{
      background-image: url( '/images/popup_close_black.svg' );
    }
    .Close::after{
      content: '';
      display: block;
      width: 1px;
      height: 1px;
      overflow: hidden;
      position: absolute;
      top: 0;
      left: 0;
      background: url( '/images/popup_close_black.svg' ) 0 -5000px no-repeat;
    }
    </style>

    <div class="Overlay" @click="${this.close}">&nbsp;</div>
    <div class="In">
      <div class="Bg"></div>
      <div class="In">
        <div class="In Text">
          <p>${yt.text1}</p>
          <p>${yt.text2}</p>
          <p>${yt.text3}</p>
        </div>
        <div class="Close" @click="${this.close}">X</div>
      </div>
    </div>
    `}async close(){const e=await m;if("number"==typeof e&&e<=62){let e=1,t=0;await g({duration:400,action:i=>{let o=i*(t-e)+e;this.style.cssText=`opacity:${o};`}})}else{let e=this.animate([{opacity:1},{opacity:0}],{duration:400,easing:"linear"});await new Promise((t=>{e.onfinish=t}))}this.remove()}}customElements.define("popup-locations-information",wt);let kt=y({browsecPremium:"browsec_premium",cancelSubscriptionAtAnyTime:"cancel_subscription_at_any_time",forOnly:"for_only",moneyBackGuarantee:"7_days_money_back_guarantee",oneSmartSettingDescription1:"one_smart_setting_description_1",oneSmartSettingDescription2:"one_smart_setting_description_2",oneSmartSettingDescriptionList1:"one_smart_setting_description_list_1",oneSmartSettingDescriptionList2:"one_smart_setting_description_list_2",youCanHaveOnlyOneSmartSetting:"you_can_have_only_1_smart_setting"});function _t(){const e=(0,v.Z)("only_X_per_month").replace(/XXX/g,this.currency+this.price);return o.dy`
  <style>
  ${d}
  :host{
    display: block;
    position: absolute;
    z-index: 3;
    top:0px;right:0px;left:0px;
    height: 100%;
    background: #fff;
  }

  .Head{
    background: #28344f;
    color: #fff;
    text-align: center;
    font-size: 17px;
    line-height: 36px;
    font-weight: 500;
    position: relative;
    padding: 9px 10px 9px;
  }

  .Close{
    position: absolute;
    top: 50%;
    right: 0;
    margin-top: -16px;
    width: 10px;
    padding-top: 10px;
    border: 11px solid transparent;
    height: 0;
    overflow: hidden;
    background: url( '/images/popup_close_2.svg#grey' ) 0 0 no-repeat;
    background-size: 100% 100%;
    cursor: pointer;
  }
  .Close:hover{
    background-image: url( '/images/popup_close_2.svg#white' );
  }
  .Close::after{
    content: '';
    display: block;
    position: absolute;
    width: 1px;
    height: 1px;
    top: 0;
    left: 0;
    background: url( '/images/popup_close_2.svg#white' ) 0 -5000px no-repeat;
  }

  .Text{
    padding: 20px 25px;
    color: #28344f;
    line-height: 1.35;
  }
  .Title{
    font-size: 18px;
    font-weight: 600;
    padding-bottom: 15px;
  }
  .Description{
    font-size: 16px;
  }
  .Description p{
    padding-bottom: 1em;
  }
  .Description ul{
    list-style: none;
  }
  .Description ul > li{
    position: relative;
    padding-left: 20px;
  }
  .Description ul > li::after{
    content: '';
    background: url( '/images/popup-help/check.svg' ) 0 0 no-repeat;
    background-size: 100% 100%;
    width: 12px;
    overflow:hidden;font-size:0;text-indent:-9999px;height:0;
    padding-top: 9px;
    position: absolute;
    top: 50%;
    margin-top: -5px;
    left: 0;
  }

  .Button_Out{
    /* position: absolute;right:5px;bottom:5px;left:5px; */
    padding: 0 5px;
  }
  .Button{
    display: table;
    width: 100%;
    height: 60px;
    background: #3d973f;
    text-align: center;
    border-radius: 4px;
    position: relative;
  }
  .Button:link,
  .Button:visited,
  .Button:hover,
  .Button:active{
    color: #fff;
    text-decoration: none;
  }
  .Button *{
    cursor: pointer;
  }
  .Button > .In{
    display: table-cell;
    vertical-align: middle;
  }

  .Button_Name{
    display: block;
    font-size: 16px;
    font-weight: 600;
  }
  .Button_Name.uppercase{
    text-transform: uppercase;
  }

  .Button_Price{
    display: block;
    font-size: 14px;
  }
  .Button_Price_Value{
    font-size: 14px;
    font-weight: bold;
  }
  .Button_Price_OldValue{
    font-size: 12px;
    text-decoration: line-through;
    color: #9aca9f;
    margin-left: 3px;
  }

  .Button_Discount{
    display: block;
    position: absolute;
    top: 0;
    bottom: 0;
    right: 25px;
  }
  .Button_Discount > .In{
    width: 54px;
    height: 54px;
    background: url( '/images/discount.svg' ) 0 0 no-repeat;
    display: table;
    position: absolute;
    right: 0;
    top: calc(50% - 54px / 2);
  }
  .Button_Discount > .In > .In{
    display: table-cell;
    vertical-align: middle;
  }
  .Button_Discount_Minus{
    display: inline-block;
    vertical-align: middle;
    font-size: 16px;
    font-weight: bold;
  }
  .Button_Discount_Value{
    display: inline-block;
    vertical-align: middle;
    font-size: 23px;
    font-weight: bold;
  }
  .Button_Discount_Percent{
    display: inline-block;
    vertical-align: middle;
    font-size: 12px;
    font-weight: bold;
  }

  .ExtraText{
    color: #808080;
    font-size: 12px;
    text-align: center;
    padding-top: 7px;
  }
  </style>

  <div class="Head">
    ${kt.browsecPremium}
    <div class="Close" @click="${this.close}"></div>
  </div>
  <div class="Text">
    <div class="Title">${kt.youCanHaveOnlyOneSmartSetting}</div>
    <div class="Description">
      <p>${kt.oneSmartSettingDescription1}</p>
      <p>${kt.oneSmartSettingDescription2}</p>
      <ul>
        <li>${kt.oneSmartSettingDescriptionList1}</li>
        <li>${kt.oneSmartSettingDescriptionList2}</li>
      </ul>
    </div>
  </div>
  <div class="Button_Out">
    <a href="${this.premiumLink}" class="Button" @click="${this.linkClick}" target="_blank">
      <span class="In">
        <span class="Button_Name ${this.trialDays&&!this.withPrice?"uppercase":""}">
          ${this.buttonText}
        </span>
      ${(()=>!this.withPrice||this.trialDays?"":o.dy`
        <span class="Button_Price">
        ${(()=>this.discount?o.dy`
          ${kt.forOnly}
          <span class="Button_Price_Value">${this.currency}${this.price}</span>
          <span class="Button_Price_OldValue">${this.currency}${this.oldPrice}</span>`:e)()}
        </span>`)()}
      </span>
      ${(()=>this.withPrice&&this.discount?o.dy`
      <span class="Button_Discount"><span class="In"><span class="In"><!--
     --><span class="Button_Discount_Minus">-</span><!--
     --><span class="Button_Discount_Value">${this.discount}</span><!--
     --><span class="Button_Discount_Percent">%</span><!--
   --></span></span></span>`:"")()}
    </a>
  </div>
  ${(()=>{if(!this.withPrice)return"";const e=this.trialDays?kt.cancelSubscriptionAtAnyTime:kt.moneyBackGuarantee;return o.dy`
    <div class="ExtraText">${e}</div>`})()}`}class Et extends((0,C.$)(E.Z)(o.oi)){render(){return _t.call(this)}static get properties(){return{buttonText:{type:String},currency:{type:String},discount:{type:Number},oldPrice:{type:Number},premiumLink:{type:String},price:{type:Number},trialDays:{type:Number}}}constructor(){super(),this.withPrice=1===Math.floor(2*Math.random())}connectedCallback(){if(super.connectedCallback(),this.firstConnect)return;this.firstConnect=!0;let e=this.extraText;e&&(e=". "+e),p.Z.partial({category:"extension",action:"show_premium_div",label:"premium_div_"+this.buttonText+e}),(async()=>{const e=c().experiments.firstSmartSettingTip.id,{experiments:t}=await E.Z.getStateAsync(),i=t[e];i&&(this.exp215variant=i,p.Z.full({category:"Exp215SsPremDiv_"+("1"===i?"B":"A"),action:"View"}))})()}stateChanged({prices:e,priceTrial:t}){const{currency:i,price:o,oldPrice:n,trialDays:s}=ye({prices:e,priceTrial:t});this.currency=i,this.price=o,this.oldPrice=n,this.trialDays=s}get buttonText(){return this.withPrice?this.trialDays?(0,v.Z)("get_N_days_free_premium_trial").replace(/XXX/g,String(this.trialDays)):this.discount?(0,v.Z)("get_monthly_premium"):(0,v.Z)("upgrade_to_premium"):(0,v.Z)("get_premium_now")}get discount(){return this.oldPrice?Math.floor(100*(this.oldPrice-this.price)/this.oldPrice):0}get extraText(){return!this.withPrice||this.trialDays?"":this.discount?(0,v.Z)("for_only")+" "+this.currency+this.price:(0,v.Z)("only_X_per_month").replace(/XXX/g,this.currency+this.price)}get premiumLink(){var e;let t=this.extraText;t&&(t=". "+t);const i=E.Z.getStateSync(),o=Date.now(),n=i.promotions.find((({from:e,till:t,tariffs:i})=>e<=o&&o<=t&&i)),s=null!==(e=null==n?void 0:n.id)&&void 0!==e?e:"default_campaign",r=(()=>{if(!n)return ht;const{tariffs:e}=n;if(!e)throw new Error('No "tariffs" property in tariff');return e.map((({price:{currency:e,value:t},duration:i})=>({currency:e,duration:i,value:t})))})(),a={feature:"smartsettings",plan_id:(()=>{const e=r.map((({duration:e,value:t})=>({duration:e,pricePerMonth:t/e}))).sort((({pricePerMonth:e},{pricePerMonth:t})=>e-t)),{duration:t}=e[0];switch(t){case 1:return"monthly";case 12:return"annual";case 24:return"biennial";default:throw new Error("Incorrect duration")}})(),utm_source:"chromium extension",utm_medium:"premium_div",utm_campaign:s,utm_term:this.buttonText+t},l=[];switch(i.experiments[c().experiments.fastServersWarning.id]){case"0":l.push("178_a");break;case"1":l.push("178_b");break;case"2":l.push("178_c");break;case"3":l.push("178_d")}switch(i.experiments[c().experiments.firstSmartSettingTip.id]){case"0":l.push("215_a");break;case"1":l.push("215_b")}return l.length&&(a.expvarid=l.join(",")),F({action:e=>Object.assign(e,a),storeState:i,url:(null==n?void 0:n.clickUrl)||R.Z.premium})}async close(){const e=await m;if("number"==typeof e&&e<=62){const e=0,t=-100;await g({duration:800,action:i=>{const o=i*(t-e)+e;this.style.cssText=`top:${o}%;`}})}else{const e=this.animate([{top:0},{top:"-100%"}],{duration:800,easing:"linear"});await new Promise((t=>{e.onfinish=t}))}this.remove()}async linkClick(){var e,t;p.Z.partial({category:"premium",action:"click"}),this.exp215variant&&p.Z.full({category:"Exp215SsPremDiv_"+("1"===this.exp215variant?"B":"A"),action:"Click"}),await new Promise((e=>{setTimeout(e,50)})),null===(e=self)||void 0===e||null===(t=e.close)||void 0===t||t.call(e)}}customElements.define("popup-premium-onerule",Et);const Ct=y({accessInternet:"access_internet_via_premium_locations",browsecPremium:"browsec_premium",cancelSubscriptionAtAnyTime:"cancel_subscription_at_any_time",dedicatedLanes:"dedicated_traffic_lanes",forOnly:"for_only",moneyBackGuarantee:"7_days_money_back_guarantee",premiumLocations:"premium_locations",premiumServers:"premium_servers",performanceGuaranteed:"top_performance_guaranteed",turboSpeed:"turbo_speed"});function $t(){const e=(0,v.Z)("only_X_per_month").replace(/XXX/g,this.currency+this.price);return o.dy`
  <style>
  ${d}
  :host{
    display: block;
    position: absolute;
    z-index: 3;
    top:0px;
    right:0px;
    left:0px;
    height: 100%;
    background: #fff;
  }

  .Head{
    background: #28344f;
    color: #fff;
    text-align: center;
    font-size: 17px;
    line-height: 36px;
    font-weight: 500;
    position: relative;
    padding: 9px 10px 9px;
    height: auto;
    overflow: visible;
  }

  .Close{
    position: absolute;
    top: 50%;
    right: 0;
    margin-top: -16px;
    width: 10px;
    padding-top: 10px;
    border: 11px solid transparent;
    height: 0;
    overflow: hidden;
    background: url( '/images/popup_close_2.svg#grey' ) 0 0 no-repeat;
    background-size: 100% 100%;
    cursor: pointer;
  }
  .Close:hover{
    background-image: url( '/images/popup_close_2.svg#white' );
  }
  .Close::after{
    content: '';
    display: block;
    position: absolute;
    width: 1px;
    height: 1px;
    top: 0;
    left: 0;
    background: url( '/images/popup_close_2.svg#white' ) 0 -5000px no-repeat;
  }

  .Features{
    padding: 10px 35px 15px 10px;
    color: #7a7c7f;
  }
  .Features > .E{
    min-height: 95px;
    box-sizing: border-box;
    padding: 2px 0 0px 90px;
    position: relative;
  }
  :host(.withPrice) .Features > .E{
    min-height: 82px;
  }
  .Features > .E::before{
    content: "";
    overflow:hidden;font-size:0;text-indent:-9999px;height:0;
    width: 67px;
    padding-top:67px;
    position: absolute;
    left: 4px;
    top: 8px;
    background-position: 0 0;
    background-repeat: no-repeat;
    background-size: 100% 100%;
  }
  .Features > .E.countries::before{
    background-image: url( '/images/promos/circles.svg#countries' );
  }
  .Features > .E.speed::before{
    background-image: url( '/images/promos/circles.svg#speed' );
  }
  .Features > .E.servers::before{
    background-image: url( '/images/promos/circles.svg#servers' );
  }

  .Feature_Name{
    color: #28334e;
    font-size: 17px;
    margin: 9px 0 2px;
    line-height: 1.29;
  }
  .Feature_Text{
    font-size: 15px;
    line-height: 1.25;
  }

  .Button_Out{
    padding: 0 5px;
  }
  .Button{
    display: table;
    width: 100%;
    height: 45px;
    background: #3d973f;
    text-align: center;
    border-radius: 4px;
    position: relative;
  }
  :host(.withPrice) .Button{
    height: 60px;
  }
  .Button:link,
  .Button:visited,
  .Button:hover,
  .Button:active{
    color: #fff;
    text-decoration: none;
  }
  .Button *{
    cursor: pointer;
  }
  .Button > .In{
    display: table-cell;
    vertical-align: middle;
  }

  .Button_Name{
    display: block;
    font-size: 17px;
  }
  .Button_Name.uppercase{
    text-transform: uppercase;
  }
  :host(.withPrice) .Button_Name{
    font-weight: 600;
    font-size: 18px;
    text-transform: uppercase;
  }
  .Button_Price{
    display: block;
    font-size: 14px;
  }
  .Button_Price_Value{
    font-size: 14px;
    font-weight: bold;
  }
  .Button_Price_OldValue{
    font-size: 12px;
    text-decoration: line-through;
    color: #9aca9f;
    margin-left: 3px;
  }

  .Button_Discount{
    display: block;
    position: absolute;
    top: 0;
    bottom: 0;
    right: 25px;
  }
  .Button_Discount > .In{
    width: 54px;
    height: 54px;
    background: url( '/images/discount.svg' ) 0 0 no-repeat;
    display: table;
    position: absolute;
    right: 0;
    top: calc(50% - 54px / 2);
  }
  .Button_Discount > .In > .In{
    display: table-cell;
    vertical-align: middle;
  }
  .Button_Discount_Minus{
    display: inline-block;
    vertical-align: middle;
    font-size: 16px;
    font-weight: bold;
  }
  .Button_Discount_Value{
    display: inline-block;
    vertical-align: middle;
    font-size: 23px;
    font-weight: bold;
  }
  .Button_Discount_Percent{
    display: inline-block;
    vertical-align: middle;
    font-size: 12px;
    font-weight: bold;
  }

  .ExtraText{
    color: #808080;
    font-size: 12px;
    text-align: center;
    padding-top: 7px;
  }
  </style>

  <div class="Head">
    Browsec Premium
    <div class="Close" @click="${this.close}"></div>
  </div>
  <div class="Features">
    <div class="E countries">
      <div class="Feature_Name">${Ct.premiumLocations}</div>
      <div class="Feature_Text">${Ct.accessInternet}</div>
    </div>
    <div class="E speed">
      <div class="Feature_Name">${Ct.turboSpeed}</div>
      <div class="Feature_Text">${Ct.dedicatedLanes}</div>
    </div>
    <div class="E servers">
      <div class="Feature_Name">${Ct.premiumServers}</div>
      <div class="Feature_Text">${Ct.performanceGuaranteed}</div>
    </div>
  </div>
  <div class="Button_Out">
    <a href="${this.premiumLink}" class="Button" @click="${this.linkClick}" target="_blank">
      <span class="In">
        <span class="Button_Name ${this.trialDays&&!this.withPrice?"uppercase":""}">
          ${this.buttonText}
        </span>
  ${(()=>!this.withPrice||this.trialDays?"":o.dy`
        <span class="Button_Price">
        ${(()=>this.discount?o.dy`
          ${Ct.forOnly}
          <span class="Button_Price_Value">${this.currency}${this.price}</span>
          <span class="Button_Price_OldValue">${this.currency}${this.oldPrice}</span>`:e)()}
        </span>`)()}
      </span>
  ${(()=>this.withPrice&&this.discount?o.dy`
      <span class="Button_Discount"><span class="In"><span class="In"><!--
     --><span class="Button_Discount_Minus">-</span><!--
     --><span class="Button_Discount_Value">${this.discount}</span><!--
     --><span class="Button_Discount_Percent">%</span><!--
   --></span></span></span>`:"")()}
    </a>
  </div>
  ${(()=>{if(!this.withPrice)return"";let e=this.trialDays?Ct.cancelSubscriptionAtAnyTime:Ct.moneyBackGuarantee;return o.dy`
  <div class="ExtraText">${e}</div>`})()}`}class St extends((0,C.$)(E.Z)(o.oi)){render(){return $t.call(this)}static get properties(){return{buttonText:{type:String},country:{type:String},currency:{type:String},discount:{type:Number},extraText:{type:String},gaCid:{type:String},oldPrice:{type:Number},premiumLink:{type:String},price:{type:Number},trialDays:{type:Number},withPrice:{type:Boolean}}}constructor(){super(),this.country="",this.withPrice=1===Math.floor(2*Math.random()),this.gaCid=(()=>{if("undefined"!=typeof browser||!document.cookie)return"";let e=document.cookie.split("; ").find((e=>e.startsWith("_ga")));return e?e.slice(10):void 0})()}connectedCallback(){if(super.connectedCallback(),this.firstConnect)return;this.firstConnect=!0;let e=this.extraText;e&&(e=". "+e),p.Z.partial({action:"show_premium_div",category:"extension",label:"premium_div_"+this.buttonText+e})}updated(e){if(e.has("withPrice")){let e=this.classList;this.withPrice?e.add("withPrice"):e.remove("withPrice")}}stateChanged({prices:e,priceTrial:t}){const{currency:i,price:o,oldPrice:n,trialDays:s}=ye({prices:e,priceTrial:t});this.currency=i,this.price=o,this.oldPrice=n,this.trialDays=s}get buttonText(){if(this.withPrice){if(this.trialDays)return(0,v.Z)("get_N_days_free_premium_trial").replace(/XXX/g,String(this.trialDays));if(this.discount)return(0,v.Z)("get_monthly_premium")}return(0,v.Z)("get_premium_now")}get discount(){return this.oldPrice?Math.floor(100*(this.oldPrice-this.price)/this.oldPrice):0}get extraText(){return!this.withPrice||this.trialDays?"":this.discount?(0,v.Z)("for_only")+" "+this.currency+this.price:(0,v.Z)("only_X_per_month").replace(/XXX/g,this.currency+this.price)}get premiumLink(){var e;let t=this.extraText;t&&(t=". "+t);const i=E.Z.getStateSync(),o=Date.now(),n=i.promotions.find((({from:e,till:t,tariffs:i})=>e<=o&&o<=t&&i)),s=null!==(e=null==n?void 0:n.id)&&void 0!==e?e:"default_campaign",r=(()=>{if(!n)return ht;const{tariffs:e}=n;if(!e)throw new Error('No "tariffs" property in tariff');return e.map((({price:{currency:e,value:t},duration:i})=>({currency:e,duration:i,value:t})))})(),a={plan_id:(()=>{const e=r.map((({duration:e,value:t})=>({duration:e,pricePerMonth:t/e}))).sort((({pricePerMonth:e},{pricePerMonth:t})=>e-t)),{duration:t}=e[0];switch(t){case 1:return"monthly";case 12:return"annual";case 24:return"biennial";default:throw new Error("Incorrect duration")}})(),utm_source:"chromium extension",utm_medium:"premium_div",utm_campaign:s,utm_term:this.buttonText+t};this.initiator&&(a.feature=(()=>{switch(this.initiator){case"premium locations":return"countries";case"smart settings":return"smartsettings";case"timezone change":return"browser_tz"}})());const l=[];switch(i.experiments[c().experiments.fastServersWarning.id]){case"0":l.push("178_a");break;case"1":l.push("178_b");break;case"2":l.push("178_c");break;case"3":l.push("178_d")}switch(i.experiments[c().experiments.firstSmartSettingTip.id]){case"0":l.push("215_a");break;case"1":l.push("215_b")}return l.length&&(a.expvarid=l.join(",")),F({action:e=>Object.assign(e,a),url:(null==n?void 0:n.clickUrl)||R.Z.premium,storeState:E.Z.getStateSync()})}async close(){const e=await m;if("number"==typeof e&&e<=62){const e=0,t=-100;await g({duration:800,action:i=>{const o=i*(t-e)+e;this.style.cssText=`top:${o}%;`}})}else{const e=this.animate([{top:0},{top:"-100%"}],{duration:800,easing:"linear"});await new Promise((t=>{e.onfinish=t}))}this.remove()}async linkClick(){var e,t;p.Z.partial({category:"premium",action:"click"}),p.Z.full({category:"locations_premium_div",action:"button_click"}),await new Promise((e=>{setTimeout(e,50)})),null===(e=self)||void 0===e||null===(t=e.close)||void 0===t||t.call(e)}}customElements.define("popup-premium",St);let Bt=y({cantStartBecauseYourProxySettingsBlocked:"cant_start_because_your_proxy_settings_blocked",fixIt:"fix_it"});class Lt extends o.oi{render(){return o.dy`
    <style>
    ${d}
    :host{
      display: block;
      font-size: 14px;
      line-height: 1.3;
      color: #28344f;
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      z-index: 2;
    }
    :host > .Overlay{
      position: absolute;
      top:0px;right:0px;bottom:0px;left:0px;
      overflow: hidden;
      text-indent: -9999px;
      font-size: 0;
      background: rgba(255, 255, 255, 0.5);
    }
    :host > .In{
      position: absolute;
      top:56px;
      right:0px;
      bottom:40px;
      left:0px;
      border: 1px solid transparent;
      border-width: 6px 5px 5px;
    }
    :host > .In > .Bg{
      position: absolute;
      top: 0;
      right: 0;
      bottom: 0;
      left: 0;
      background: #fff;
      box-shadow: 0 1px 5px 0 rgba(0, 0, 0, 0.3);
      border-radius: 4px;
      font-size: 0;
      overflow: hidden;
    }

    :host > .In > .In{
      position: relative;
      display: table;
      width: 100%;
      height: 100%;
    }
    :host > .In > .In > .In{
      display: table-cell;
      vertical-align: middle;
    }

    .Description{
      color: #28344f;
      font-size: 16px;
      line-height: 1.375;
      padding: 0 25px;
      text-align: center;
    }
    .Button{
      text-align: center;
      padding-top: 25px;
    }
    .Button input{
      display:inline-block;
      vertical-align:top;
      box-sizing: content-box;
      height: 45px;
      line-height: 45px;
      border: 0;
      cursor: pointer;
      min-width: 200px;
      padding: 0 15px;
      background: #3b9946;
      text-align: center;
      border-radius: 5px;
      color: #fff;
      font-size: 16px;
      font-weight: 600;
    }
    </style>

    <div class="Overlay">&nbsp;</div>
    <div class="In">
      <div class="Bg"></div>
      <div class="In"><div class="In">
        <div class="Description">
          ${Bt.cantStartBecauseYourProxySettingsBlocked}
        </div>
        <div class="Button"><!--
       --><input type="button" value="${Bt.fixIt}" @click="${this.fixIt}"/><!--
     --></div>
      </div></div>
    </div>
    `}async fixIt(){await(0,n.Z)({type:"create tab",options:"/pages/unblock_proxy/unblock_proxy.html"}),window.close()}}customElements.define("popup-proxy-blocked",Lt);const Pt=({block:e,ellipse:t})=>{const i=t.width/2,o=t.height/2,n="data:image/svg+xml;base64,"+btoa(`<svg viewBox="0 0 ${e.width} ${e.height}" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">\n        <mask id="clip">\n          <rect id="bg" x="0" y="0" width="100%" height="100%" fill="#fff"/>\n          <ellipse cx="${t.centerX}" cy="${t.centerY}" rx="${i}" ry="${o}" fill="#000" />\n        </mask>\n\n        <rect x="0" y="0" width="100%" height="100%" mask="url(#clip)" fill="#000"/>\n      </svg>\n      `.replace(/(\n|\r)/g,"").trim());return`-webkit-mask: url('${n}') 0 0 no-repeat;mask: url('${n}') 0 0 no-repeat;`};class It extends o.oi{render(){return o.dy`
    <style>
    ${d}
    :host{
      display: block;
      position: absolute;
      top: 0;
      left: 0;
      height: 100%;
      width: 100%;
    }
    :host > .In{
      position: absolute;
      top: 0;
      left: 0;
      height: 100%;
      width: 100%;
      background: rgba(0, 0, 0, 0.75);
      display: flex;
      align-items: center;
    }
    :host > .In > .In{
      flex-grow: 1;
    }

    .Close{
      width: 16px;
      height: 16px;
      position: absolute;
      cursor: pointer;
      font-size: 0;
      right: 20px;
      top: 20px;
      transform: rotate(45deg)
    }
    .Close::before,
    .Close::after{
      content: '';
      display: block;
      position: absolute;
      background: #fff;
      overflow: hidden;
    }
    .Close::before{
      top: 0;
      left: calc( 50% - 1px );
      height: 100%;
      width: 2px;
    }
    .Close::after{
      left: 0;
      top: calc( 50% - 1px );
      width: 100%;
      height: 2px;
    }
    .Close:hover::before,
    .Close:hover::after{
      background: #ddd;
    }

    .Title{
      color: #fff;
      font-weight: bold;
      font-size: 24px;
      text-align: center;
      padding: 0px 10px 0;
    }
    .Text{
      color: #fff;
      font-size: 20px;
      text-align: center;
      padding: 15px 10px 0;
    }

    .Arrow{
      background: url( '/images/tip_arrow.svg' ) 0 0 no-repeat;
      width: 50px;
      padding-top: 100px;
      height: 0;
      overflow: hidden;
      text-indent: -9999px;
      font-size: 0;
      position: absolute;
      top: 287px;
      left: 190px;
    }
    .Trigger{
      position: absolute;
      top: 384px;
      left: 69px;
      width: 130px;
      height: 27px;
      cursor: pointer;
    }
    </style>

    <div class="In"><div class="In">
      <div class="Title">Done!</div>
      <div class="Text">
        Click here to access your<br />
        SmartSettings list
      </div>

      <div class="Arrow"></div>
      <div class="Close" @click=${this.close}></div>
      <div class="Trigger" @click=${this.trigger}></div>
    </div></div>`}async firstUpdated(e){super.firstUpdated(e);const t=this.offsetWidth,i=this.offsetHeight,o=Pt({block:{width:t,height:i},ellipse:{width:140,height:36,centerX:134,centerY:396}}),n=this.shadowRoot.querySelector("div.In");n&&(n.style.cssText=o)}close(){this.remove(),p.Z.full({category:"Exp215SsMenuHint",action:"Close"})}trigger(){var e,t,i,o,n,s,r,a,l,c;this.remove(),p.Z.full({category:"Exp215SsMenuHint",action:"Сlick"});const d=null===(e=document.querySelector("page-switch"))||void 0===e||null===(t=e.shadowRoot)||void 0===t||null===(i=t.querySelector)||void 0===i||null===(o=i.call(t,"main-index"))||void 0===o||null===(n=o.shadowRoot)||void 0===n||null===(s=n.querySelector)||void 0===s||null===(r=s.call(n,"index-menu"))||void 0===r||null===(a=r.shadowRoot)||void 0===a||null===(l=a.querySelector)||void 0===l?void 0:l.call(a,".E.smartSettings");null==d||null===(c=d.click)||void 0===c||c.call(d)}}customElements.define("smart-settings-hint-done",It);class Tt extends o.oi{render(){return o.dy`
    <style>
    ${d}
    :host{
      display: block;
      position: absolute;
    }
    :host > .Bg{
      position: absolute;
      top:0px;
      right:0px;
      bottom:0px;
      left:0px;
      background: #faf5f5;
      border-radius: 4px;
      border: 1px solid #8e3c33;
      font-size: 0;
      box-shadow: 0 4px 16px 0 rgba(0, 0, 0, 0.2);
    }
    :host > .Bg::before,
    :host > .Bg::after{
      content: '';
      display: block;
      position: absolute;
      left: 16px;
      width: 0;
      height: 0;
      overflow: hidden;
      border: 5px solid transparent;
    }
    :host > .Bg:before{
      top: -10px;
      border-bottom-color: #8e3c33;
    }
    :host > .Bg:after{
      top: -9px;
      border-bottom-color: #faf5f5;
    }
    :host > .In{
      position: relative;
      color: #994136;
      font-size: 12px;
      padding: 4px 11px;
      line-height: 19px;
      min-height: 19px; /* NOTE border in .Bg */
      min-width: 12px;
    }
    </style>

    <div class="Bg"></div>
    <div class="In">${this.text}</div>`}static get properties(){return{text:{type:String}}}constructor(){super(),this.text=""}}customElements.define("tooltip-error",Tt);const Zt=async e=>{const t=e.animate([{opacity:1},{opacity:0}],{duration:300,easing:"linear"});await new Promise((e=>{t.onfinish=e})),e.remove()},zt=({setValue:e,setEndValue:t})=>new Promise((i=>{const o=performance.now(),n=s=>{if(s-o>=300)return t(),void i();e(`filter: blur(${3*(1-(s-o)/300)}px);`),requestAnimationFrame(n)};requestAnimationFrame(n)})),Dt=async e=>{p.Z.full({category:"onboarding",action:"onboarding1",label:"show"});const t=document.querySelector("div.MainContainer");let i;try{const e=document.querySelector("page-switch");await e.updateComplete;const t=e.shadowRoot.querySelector("main-index");await t.updateComplete,i=t.shadowRoot.querySelector("index-home"),await i.updateComplete}catch(e){return}const o=(()=>{try{return i.shadowRoot.querySelector(".Inactive_Button")}catch(e){return null}})();if(!t||!o)return;await(({button:e,destroyOnButtonClick:t,parent:i})=>new Promise((o=>{const n=window.innerWidth,s=window.innerHeight,r=e.getBoundingClientRect(),a=e.offsetHeight,l=e.offsetWidth,c=e.offsetHeight+46,d=Pt({block:{width:n,height:s},ellipse:{centerX:n/2,centerY:r.y+e.offsetHeight/2,height:c,width:e.offsetWidth+40}}),h=document.createElement("div");h.textContent=e.textContent;const g=getComputedStyle(e);h.style.cssText=`background-color: ${g.getPropertyValue("background-color")};border-radius: ${g.getPropertyValue("border-radius")};color: ${g.getPropertyValue("color")};font-family: ${g.getPropertyValue("font-family")};font-size: ${g.getPropertyValue("font-size")};height: ${a}px;line-height: ${g.getPropertyValue("line-height")};width: ${l}px;text-align: center;position: absolute;top: ${r.y}px;left: ${(n-l)/2}px;cursor: pointer;`;const m=document.createElement("first-start-tips-button");m.style.cssText=d,m.bottom=s-r.y+(c-a)/2+6,h.addEventListener("click",(async()=>{p.Z.full({category:"onboarding",action:"onboarding1",label:"vpn_on"}),u.Z.set("startup tips shown",!0),e.click(),t?(i.style.cssText="",m.remove(),h.remove(),o(!1)):(m.remove(),h.remove(),o(!0))})),m.addEventListener("close",(async()=>{p.Z.full({category:"onboarding",action:"onboarding1",label:"close"}),await Promise.all([Zt(m),zt({setValue:e=>{i.style.cssText=e+d},setEndValue:()=>{i.style.cssText=""}})]),h.remove(),o(!1)})),i.style.cssText="filter: blur(3px);"+d,document.body.append(m),document.body.append(h)})))({button:o,destroyOnButtonClick:"1"===e,parent:t})&&await(e=>new Promise((t=>{p.Z.full({category:"onboarding",action:"onboarding2",label:"show"});const i=document.createElement("first-start-tips-protected");i.addEventListener("close",(async()=>{await Promise.all([Zt(i),zt({setValue:t=>{e.style.cssText=t},setEndValue:()=>{e.style.cssText=""}})]),t()})),e.style.cssText="filter: blur(3px);",document.body.append(i)})))(t)};var Ot=i(5221),At=i.n(Ot),Nt=i(3355),Ft=i(1690);const Rt=e=>{const{experiments:t,user:i}=e;return"1"===t[c().experiments.accountSuspended.id]&&("logined"===i.type&&!i.premium&&i.loginData.subscription.auto_renewal)};(async()=>{const e=new Ft.Z("Popup: page load"),t={domainZoneList:new Nt.Z,storeState:E.Z.ready};{const e=new Ft.Z("Popup: domainZoneList");t.domainZoneList.then((()=>{e.end()}))}{const e=new Ft.Z("Popup: store.ready");t.storeState.then((()=>{e.end()}))}let i;(async()=>{const e=await At().storage.local.get(null);i=e,Array.isArray(e.domainZoneList)&&t.domainZoneList.resolve(e.domainZoneList),E.Z.initiate({type:"storage",value:e})})(),(async()=>{const e=await(0,n.Z)({type:"domain zone list"});t.domainZoneList.resolve(e)})(),(async()=>{const e=await(0,n.Z)({type:"store: get state"});E.Z.initiate({type:"store state",value:e})})();const o=await t.domainZoneList,s=await t.storeState;Object.assign(window,{domainZoneList:o});const r=new Ft.Z("Popup: firstPopupOpen"),a=i?i.firstPopupOpen:await u.Z.get("firstPopupOpen");r.end();const l=new Ft.Z("Popup: get control state"),d=await(async()=>{if("undefined"!=typeof browser||!s.pac.broken)return!0;return!!await f.Z.getControlState()&&(await f.Z.setState({broken:!1}),!0)})();if(l.end(),(0,n.Z)({type:"popup open"}),"index:home"!==E.Z.getStateSync().page&&E.Z.dispatch({type:"Page: set",page:"index:home"}),"installed"===a){p.Z.partial({category:"extension",action:"first_popup_open"});const e=i?i.installVersion:await u.Z.get("installVersion");"string"==typeof e&&((e,t)=>{if(e===t)return 0;let i=e.split(".").map((e=>Number(e))),o=t.split(".").map((e=>Number(e))),n=Math.min(i.length,o.length);for(let e=0;e<n;e++){if(i[e]>o[e])return 1;if(i[e]<o[e])return-1}return i.length>o.length?1:i.length<o.length?-1:0})(e,"3.28.6")>=0&&p.Z.full({category:"onboarding",action:"first_popup_open",label:At().runtime.getManifest().version}),u.Z.set("firstPopupOpen","fulfilled")}(async()=>{(i?i.emptyReserveDomains:await u.Z.get("emptyReserveDomains"))&&u.Z.set("emptyReserveDomains",!1)})(),(()=>{const t=document.querySelector("div.MainContainer");if(!t)return;const i=new Ft.Z("Popup: append elements"),o=["main-head","page-switch"];d||o.push("popup-proxy-blocked"),o.forEach((e=>{t.append(document.createElement(e))})),(async()=>{if(!d)return;const e=s.experiments[c().experiments.startupTips.id];if(!e||"0"===e)return;await u.Z.get("startup tips shown")||Dt(e)})();Rt(s)&&(p.Z.full({category:"Exp164",action:"Lockout",label:"View"}),t.append(document.createElement("account-suspended"))),i.end(),e.end(),E.Z.onChange((({promotions:e,user:t})=>Boolean(t.email)),(async e=>{if(!e)return;const i=await E.Z.getStateAsync();Rt(i)&&t.append(document.createElement("account-suspended"))})),(async()=>{if("3"!==s.experiments[c().experiments.fastServersWarning.id])return;await u.Z.get("Experiment 178: initial popup shown")||(u.Z.set("Experiment 178: initial popup shown",!0),t.append(document.createElement("fast-servers-initial")),p.Z.full({category:"Exp178",action:"Congrats",label:"View"}))})(),(async()=>{const e=s.experiments[c().experiments.fastServersWarning.id];if("2"!==e&&"3"!==e)return;if(await u.Z.get("Experiment 178: expiration popup shown"))return;const i=await u.Z.get("statistics"),o=null==i?void 0:i.installDate;"number"==typeof o&&((Date.now()-o)/864e5<=7||(u.Z.set("Experiment 178: expiration popup shown",!0),t.append(document.createElement("fast-servers-expired")),p.Z.full({category:"Exp178",action:"NewPayWall",label:"View"})))})()})()})(),window.onerror=(e,t,i)=>((0,n.Z)({type:"popup error",data:{message:e,fileName:t,lineNumber:i}}),!1),re.addListener((e=>{(async e=>{"custom"===(null==e?void 0:e.type)&&(await new Promise((e=>{setTimeout(e,2e3)})),(0,n.Z)({type:"personal banner view",id:e.promotionId}))})(e)})),(async()=>{var e,t,i,o;const n=c().experiments.firstSmartSettingTip.id,{experiments:s}=await E.Z.getStateAsync();if("1"!==s[n])return;await new Promise((async e=>{if(4===await u.Z.get("Experiment 215: state"))return void e();const t=i=>{const o=i["Experiment 215: state"];o&&4===o.newValue&&(u.Z.removeListener(t),e())};u.Z.addListener(t)})),await u.Z.set("Experiment 215: state",5);const r=await u.Z.get("Experiment 215: domains");if(!r)return;const a=2===r.length?r[0]:void 0;p.Z.full({category:"Exp215AddSs",action:"View",label:a}),E.Z.dispatch({type:"Page: set",page:"index:smart settings hint"}),await new Promise((e=>{setTimeout(e,0)}));const l=null===(e=document.querySelector("page-switch"))||void 0===e||null===(t=e.shadowRoot)||void 0===t||null===(i=t.querySelector("main-index"))||void 0===i||null===(o=i.shadowRoot)||void 0===o?void 0:o.querySelector("smart-settings-hint");if(!l)throw new Error("No smart-settings-hint element");const{pac:d}=await E.Z.getStateAsync();a&&(l.domain=a),l.country=d.country})()}},i={};function o(e){var n=i[e];if(void 0!==n)return n.exports;var s=i[e]={id:e,loaded:!1,exports:{}};return t[e](s,s.exports,o),s.loaded=!0,s.exports}o.m=t,e=[],o.O=(t,i,n,s)=>{if(!i){var r=1/0;for(d=0;d<e.length;d++){for(var[i,n,s]=e[d],a=!0,l=0;l<i.length;l++)(!1&s||r>=s)&&Object.keys(o.O).every((e=>o.O[e](i[l])))?i.splice(l--,1):(a=!1,s<r&&(r=s));if(a){e.splice(d--,1);var c=n();void 0!==c&&(t=c)}}return t}s=s||0;for(var d=e.length;d>0&&e[d-1][2]>s;d--)e[d]=e[d-1];e[d]=[i,n,s]},o.n=e=>{var t=e&&e.__esModule?()=>e.default:()=>e;return o.d(t,{a:t}),t},o.d=(e,t)=>{for(var i in t)o.o(t,i)&&!o.o(e,i)&&Object.defineProperty(e,i,{enumerable:!0,get:t[i]})},o.g=function(){if("object"==typeof globalThis)return globalThis;try{return this||new Function("return this")()}catch(e){if("object"==typeof window)return window}}(),o.hmd=e=>((e=Object.create(e)).children||(e.children=[]),Object.defineProperty(e,"exports",{enumerable:!0,set:()=>{throw new Error("ES Modules may not assign module.exports or exports.*, Use ESM export syntax, instead: "+e.id)}}),e),o.o=(e,t)=>Object.prototype.hasOwnProperty.call(e,t),o.r=e=>{"undefined"!=typeof Symbol&&Symbol.toStringTag&&Object.defineProperty(e,Symbol.toStringTag,{value:"Module"}),Object.defineProperty(e,"__esModule",{value:!0})},o.j=42,(()=>{var e={42:0};o.O.j=t=>0===e[t];var t=(t,i)=>{var n,s,[r,a,l]=i,c=0;for(n in a)o.o(a,n)&&(o.m[n]=a[n]);if(l)var d=l(o);for(t&&t(i);c<r.length;c++)s=r[c],o.o(e,s)&&e[s]&&e[s][0](),e[r[c]]=0;return o.O(d)},i=self.webpackChunkbrowsec_extension=self.webpackChunkbrowsec_extension||[];i.forEach(t.bind(null,0)),i.push=t.bind(null,i.push.bind(i))})();var n=o.O(void 0,[592],(()=>o(9206)));n=o.O(n)})();